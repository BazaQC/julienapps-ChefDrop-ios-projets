import { serve } from "https://deno.land/std@0.177.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const { title } = await req.json();

    if (!title) {
      return new Response(JSON.stringify({ error: "Titre manquant" }), {
        status: 400,
        headers: corsHeaders,
      });
    }

    // ÉTAPE 1 — Claude génère un prompt photo détaillé en anglais
    const claudeKey = Deno.env.get("CléPourChefDrop");

    const claudeResponse = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "x-api-key": claudeKey,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
      },
      body: JSON.stringify({
        model: "claude-haiku-4-5-20251001",
        max_tokens: 100,
        messages: [{
          role: "user",
          content: `You are a food photography prompt expert. Create a short image generation prompt for this recipe.

Rules:
- Describe exactly the dish with its key ingredients
- Add: "food photography, natural light, top view, restaurant quality"
- Max 20 words total
- Return ONLY the prompt, nothing else

Recipe: "${title}"

Example: "shrimp tacos with poached shrimp lime cilantro, food photography, natural light, top view, restaurant quality"`
        }],
      }),
    });

    const claudeData = await claudeResponse.json();
    const imagePrompt = claudeData.content?.[0]?.text?.trim() ?? title;
    console.log("� Prompt image:", imagePrompt);

    // ÉTAPE 2 — Replicate génère l'image avec Flux Schnell
    const replicateKey = Deno.env.get("REPLICATE_API_KEY");

    const replicateResponse = await fetch("https://api.replicate.com/v1/models/black-forest-labs/flux-schnell/predictions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${replicateKey}`,
        "Content-Type": "application/json",
        "Prefer": "wait",
      },
      body: JSON.stringify({
        input: {
          prompt: imagePrompt,
          go_fast: true,
          num_outputs: 1,
          aspect_ratio: "16:9",
          output_format: "webp",
          output_quality: 80,
        },
      }),
    });

    const replicateData = await replicateResponse.json();
    console.log("�️ Replicate status:", replicateResponse.status);

    const imageUrl = replicateData.output?.[0];

    if (!imageUrl) {
      console.error("❌ Pas d'image Replicate:", JSON.stringify(replicateData));
      return new Response(
        JSON.stringify({ error: "Replicate: pas d'image générée" }),
        { status: 500, headers: corsHeaders }
      );
    }

    console.log("✅ Image générée:", imageUrl);

    return new Response(
      JSON.stringify({ imageUrl }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );

  } catch (err) {
    console.error("� Erreur:", err.message);
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500,
      headers: corsHeaders,
    });
  }
});
