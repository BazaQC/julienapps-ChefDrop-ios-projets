// ============================================
// RecipeViewModel.swift
// ChefDrop
// ============================================
import SwiftUI
import SwiftData
 
@Observable
class RecipeViewModel {
 
    var recipes: [Recipe] = []
    var showPaywall: Bool = false
    var showSideMenu: Bool = false
    var showImport: Bool = false
 
    // MARK: - Filtres multi-sélection
    var selectedCategories: Set<RecipeCategory> = []
    var selectedFitnessFilters: Set<FitnessFilter> = []
 
    // MARK: - Mode liste
    var listMode: RecipeListMode = .all
 
    let parser = RecipeParser()
 
    // MARK: - Logique filtres combinés
    var filteredRecipes: [Recipe] {
        var result: [Recipe]
 
        switch listMode {
        case .all:       result = recipes
        case .favorites: result = favoriteRecipes
        case .tryLater:  result = tryLaterRecipes
        }
 
        if !selectedCategories.isEmpty {
            result = result.filter { recipe in
                !recipe.categories.filter { selectedCategories.contains($0) }.isEmpty
            }
        }
 
        if !selectedFitnessFilters.isEmpty {
            result = result.filter { recipe in
                selectedFitnessFilters.allSatisfy { $0.matches(recipe) }
            }
        }
 
        if !selectedFitnessFilters.isEmpty {
            result = result.sorted { a, b in
                let scoreA = selectedFitnessFilters.filter { $0.matches(a) }.count
                let scoreB = selectedFitnessFilters.filter { $0.matches(b) }.count
                if scoreA != scoreB { return scoreA > scoreB }
                return a.title < b.title  // Alphabétique si score égal
            }
        } else {
            // Toujours alphabétique — Favoris, À essayer, Toutes
            result = result.sorted { $0.title < $1.title }
        }
 
        return result
    }
 
    // MARK: - Computed properties Favoris / À essayer
    var favoriteRecipes: [Recipe] {
        recipes.filter { $0.isFavorite }
    }
 
    var tryLaterRecipes: [Recipe] {
        recipes.filter { $0.isTryLater }
    }
 
    // MARK: - Toggle Favoris / À essayer
    func toggleFavorite(_ recipe: Recipe, context: ModelContext) {
        recipe.isFavorite.toggle()
        try? context.save()
        loadRecipes(context: context)
    }
 
    func toggleTryLater(_ recipe: Recipe, context: ModelContext) {
        recipe.isTryLater.toggle()
        try? context.save()
        loadRecipes(context: context)
    }
 
    // MARK: - Toggle filtres
    func toggleCategory(_ category: RecipeCategory) {
        if selectedCategories.contains(category) {
            selectedCategories.remove(category)
        } else {
            selectedCategories.insert(category)
        }
    }
 
    func toggleFitnessFilter(_ filter: FitnessFilter) {
        if selectedFitnessFilters.contains(filter) {
            selectedFitnessFilters.remove(filter)
        } else {
            selectedFitnessFilters.insert(filter)
        }
    }
 
    func clearAllFilters() {
        selectedCategories.removeAll()
        selectedFitnessFilters.removeAll()
        listMode = .all
        withAnimation(.spring()) { showSideMenu = false }
    }
 
    func applyAndClose() {
        withAnimation(.spring()) { showSideMenu = false }
    }
 
    // MARK: - Compatibilité
    var selectedCategory: RecipeCategory? {
        get { selectedCategories.first }
        set {
            selectedCategories.removeAll()
            if let cat = newValue { selectedCategories.insert(cat) }
        }
    }
 
    func selectCategory(_ category: RecipeCategory?) {
        selectedCategories.removeAll()
        selectedFitnessFilters.removeAll()
        if let cat = category { selectedCategories.insert(cat) }
        withAnimation(.spring()) { showSideMenu = false }
    }
 
    // MARK: - SwiftData
 
    func loadRecipes(context: ModelContext) {
        do {
            let descriptor = FetchDescriptor<Recipe>(
                sortBy: [SortDescriptor(\.createdAt, order: .reverse)]
            )
            recipes = try context.fetch(descriptor)
        } catch {
            print("❌ Erreur chargement recettes: \(error)")
        }
    }
 
    /// Sauvegarde une recette — vérifie les crédits via PremiumViewModel
    func saveRecipe(_ recipe: Recipe, context: ModelContext, premiumViewModel: PremiumViewModel) {
        guard premiumViewModel.checkCreditsAndShowPaywall() else { return }
        context.insert(recipe)
        try? context.save()
        premiumViewModel.consumeCredit()
        loadRecipes(context: context)
    }
 
    /// Import une recette depuis un texte — consomme 1 crédit si succès
    func importRecipe(
        from text: String,
        context: ModelContext,
        localeManager: LocaleManager,
        premiumViewModel: PremiumViewModel
    ) async -> Bool {
        guard premiumViewModel.checkCreditsAndShowPaywall() else { return false }
 
        guard let recipe = await parser.parseRecipe(from: text, localeManager: localeManager) else {
            return false
        }
 
        context.insert(recipe)
        try? context.save()
        premiumViewModel.consumeCredit()
        loadRecipes(context: context)
        return true
    }
 
    func deleteRecipe(_ recipe: Recipe, context: ModelContext) {
        context.delete(recipe)
        try? context.save()
        loadRecipes(context: context)
    }
}
