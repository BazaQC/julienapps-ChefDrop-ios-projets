// ============================================
// PremiumViewModel.swift
// ChefDrop
//
// Gère tout ce qui concerne le système de crédits :
// - 5 crédits gratuits à la création du compte
// - Achats consommables (crédits empilables)
// - Affichage du paywall quand crédits = 0
// - Délègue les achats StoreKit à PremiumManager
// ============================================
 
import SwiftUI
import StoreKit
 
// MARK: - Packs de Crédits Disponibles
// Les 3 packs d'achat unique (one-time, consommables)
enum CreditPack: String, CaseIterable {
    case starter = "Starter"   // +30 crédits  — 2,99$
    case chef    = "Chef"      // +120 crédits — 5,99$
    case pro     = "Pro"       // +300 crédits — 9,99$
 
    // Nombre de crédits ajoutés par ce pack
    var creditsGranted: Int {
        switch self {
        case .starter: return 30
        case .chef:    return 120
        case .pro:     return 300
        }
    }
 
    // Prix affiché dans l'UI
    var price: String {
        switch self {
        case .starter: return "2,99$"
        case .chef:    return "5,99$"
        case .pro:     return "9,99$"
        }
    }
 
    // Sous-titre affiché dans le bouton
    var subtitle: String {
        switch self {
        case .starter: return "+30 recettes"
        case .chef:    return "+120 recettes"
        case .pro:     return "+300 recettes"
        }
    }
}
 
// MARK: - PremiumViewModel
@Observable
class PremiumViewModel {
 
    // MARK: - Propriétés
 
    // Crédits restants — commence à 5 pour les nouveaux utilisateurs
    var remainingCredits: Int {
        get { UserDefaults.standard.integer(forKey: "remainingCredits") }
        set { UserDefaults.standard.set(newValue, forKey: "remainingCredits") }
    }
 
    // Contrôle l'affichage du Paywall
    var showPaywall: Bool = false
 
    // État du chargement pendant un achat
    var isLoading: Bool = false
 
    // Produits disponibles chargés depuis l'App Store
    var availableProducts: [Product] = []
 
    // Message d'erreur si achat échoue
    var errorMessage: String? = nil
 
    // MARK: - Propriétés Privées
 
    // Service StoreKit — fait le vrai travail en arrière-plan
    let premiumManager = PremiumManager()
 
    // Clé pour savoir si c'est la première ouverture
    private let hasInitialCreditsKey = "hasInitialCredits"
 
    // MARK: - Init
    init() {
        // Donne 5 crédits gratuits à la toute première ouverture
        if !UserDefaults.standard.bool(forKey: hasInitialCreditsKey) {
            UserDefaults.standard.set(5, forKey: "remainingCredits")
            UserDefaults.standard.set(true, forKey: hasInitialCreditsKey)
        }
        
        // Charge les produits disponibles
        Task { await loadProducts() }
    }
 
    // MARK: - Vérifier les Crédits
 
    /// Retourne true si l'utilisateur a encore des crédits disponibles
    var canImportRecipe: Bool {
        return remainingCredits > 0
    }
 
    // MARK: - Consommer un Crédit
 
    /// Appeler après chaque import réussi pour déduire 1 crédit
    func consumeCredit() {
        guard remainingCredits > 0 else { return }
        remainingCredits -= 1
        print("✅ Crédit consommé — Restants: \(remainingCredits)")
    }
 
    // MARK: - Vérifier et Afficher Paywall
 
    /// Appelé avant chaque import — retourne false et affiche le paywall si plus de crédits
    func checkCreditsAndShowPaywall() -> Bool {
        if remainingCredits <= 0 {
            showPaywall = true
            return false
        }
        return true
    }
 
    // MARK: - Ajouter des Crédits
 
    /// Appelé après un achat réussi pour créditer le compte
    func addCredits(_ amount: Int) {
        remainingCredits += amount
        showPaywall = false
        print("✅ \(amount) crédits ajoutés — Total: \(remainingCredits)")
    }
 
    // MARK: - Acheter un Pack
 
    /// Délègue l'achat au PremiumManager
    func purchase(_ product: Product) async {
        isLoading = true
        errorMessage = nil
 
        await premiumManager.purchase(product)
 
        // Si l'achat a réussi, PremiumManager nous dit quel pack ajouter
        if let pack = premiumManager.lastPurchasedPack {
            addCredits(pack.creditsGranted)
            premiumManager.lastPurchasedPack = nil
        }
 
        errorMessage = premiumManager.errorMessage
        isLoading = false
    }
 
    // MARK: - Restaurer les Achats
 
    /// Note : les consommables ne sont pas restaurables (comportement normal App Store)
    /// On affiche un message informatif à l'utilisateur
    func restorePurchases() async {
        isLoading = true
        // Les achats consommables ne se restaurent pas — c'est le comportement
        // standard App Store pour les crédits/consommables
        errorMessage = "Les crédits sont des achats uniques et ne peuvent pas être restaurés."
        isLoading = false
    }
 
    // MARK: - Charger les Produits
 
    /// Délègue le chargement au PremiumManager
    func loadProducts() async {
        await premiumManager.loadProducts()
        availableProducts = premiumManager.availableProducts
    }
}
 
