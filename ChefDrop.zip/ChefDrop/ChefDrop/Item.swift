//
//  Item.swift
//  ChefDrop
//
//  Created by Julien Carmel on 2026-03-18.
//

// Item.swift
// Demo model removed. This file is intentionally empty and kept as a placeholder.
