//// ============================================
// ChefDropApp.swift
// ChefDrop
// ============================================
import SwiftUI
import SwiftData

@main
struct ChefDropApp: App {

    @AppStorage("isLightMode") private var isLightMode: Bool = false

    // Crée un nouveau store "chefbook2" — évite tout conflit
    // avec l'ancien store "default" qui avait l'ancienne structure
    let container: ModelContainer = {
        let schema = Schema([Recipe.self])
        let config = ModelConfiguration(
            "chefbook3",  // ← nouveau nom = nouveau fichier propre
            schema: schema,
            isStoredInMemoryOnly: false
        )
        do {
            return try ModelContainer(for: schema, configurations: config)
        } catch {
            fatalError("❌ Impossible de créer le ModelContainer: \(error)")
        }
    }()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(LocaleManager.shared)
                .modelContainer(container)
                .preferredColorScheme(isLightMode ? .light : .dark)
        }
    }
}
