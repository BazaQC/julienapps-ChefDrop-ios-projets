// ============================================
// ContentView.swift
// ChefDrop
//
// Point d'entrée principal de l'UI.
// Initialise les ViewModels et lance HomeView.
// Gère le thème et la langue au niveau racine
// pour un changement instantané dans toute l'app.
// ============================================
import SwiftUI

// MARK: - ContentView
struct ContentView: View {
    
    @State private var recipeViewModel = RecipeViewModel()
    @State private var premiumViewModel = PremiumViewModel()
    @AppStorage("isLightMode") private var isLightMode: Bool = false
    @Environment(LocaleManager.self) private var localeManager
    
    var body: some View {
        HomeView(
            viewModel: recipeViewModel,
            premiumViewModel: premiumViewModel
        )
        .preferredColorScheme(isLightMode ? .light : .dark)
        
        // MARK: - Sheet Import
        .fullScreenCover(isPresented: $recipeViewModel.showImport) {
            ImportView(viewModel: recipeViewModel, premiumViewModel: premiumViewModel)
                .environment(localeManager) // ✅ Sinon la sheet ne reçoit pas la langue
                .preferredColorScheme(isLightMode ? .light : .dark)
        }
        
        // MARK: - Sheet Paywall
        .sheet(isPresented: $recipeViewModel.showPaywall) {
            PaywallView(
                premiumViewModel: premiumViewModel,
                viewModel: recipeViewModel
            )
            .environment(localeManager) // ✅ Sinon la sheet ne reçoit pas la langue
            .preferredColorScheme(isLightMode ? .light : .dark)
        }
    }
}
