// ============================================
// AppColors.swift
// ChefDrop
//
// Couleurs centralisées et adaptatives.
// Changent automatiquement selon Dark/Light Mode.
// Utiliser AppColors.xxx partout dans l'app.
// ============================================

import SwiftUI

// MARK: - AppColors
struct AppColors {
    
    // MARK: - Fonds
    
    // Fond principal — noir en Dark, blanc cassé en Light
    static let background = Color(UIColor { trait in
        trait.userInterfaceStyle == .dark
        ? UIColor(red: 0.08, green: 0.08, blue: 0.08, alpha: 1)
        : UIColor(red: 0.96, green: 0.96, blue: 0.96, alpha: 1)
    })
    
    // Fond secondaire — cartes, cellules
    static let backgroundSecondary = Color(UIColor { trait in
        trait.userInterfaceStyle == .dark
        ? UIColor(red: 0.13, green: 0.13, blue: 0.13, alpha: 1)
        : UIColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 1)
    })
    
    // Fond tertiaire — inputs, placeholders
    static let backgroundTertiary = Color(UIColor { trait in
        trait.userInterfaceStyle == .dark
        ? UIColor(red: 0.18, green: 0.18, blue: 0.18, alpha: 1)
        : UIColor(red: 0.88, green: 0.88, blue: 0.88, alpha: 1)
    })
    
    // Fond menu latéral — légèrement différent du fond principal
    static let backgroundMenu = Color(UIColor { trait in
        trait.userInterfaceStyle == .dark
        ? UIColor(red: 0.12, green: 0.12, blue: 0.12, alpha: 1)
        : UIColor(red: 0.98, green: 0.98, blue: 0.98, alpha: 1)
    })
    
    // MARK: - Textes
    
    // Texte principal — blanc en Dark, presque noir en Light
    static let textPrimary = Color(UIColor { trait in
        trait.userInterfaceStyle == .dark
        ? UIColor.white
        : UIColor(red: 0.1, green: 0.1, blue: 0.1, alpha: 1)
    })
    
    // Texte secondaire — gris dans les deux modes
    static let textSecondary = Color(UIColor { trait in
        trait.userInterfaceStyle == .dark
        ? UIColor.systemGray
        : UIColor.systemGray
    })
    
    // MARK: - Accent
    
    // Or — couleur identité ChefDrop, toujours la même
    static let gold = Color(red: 0.83, green: 0.63, blue: 0.09)
    
    // MARK: - Séparateurs
    
    // Ligne de séparation subtile
    static let separator = Color(UIColor { trait in
        trait.userInterfaceStyle == .dark
        ? UIColor.white.withAlphaComponent(0.1)
        : UIColor.black.withAlphaComponent(0.1)
    })
    
    // MARK: - Macros (toujours fixes)
    static let macroProtein = Color(red: 0.3, green: 0.7, blue: 0.4)
    static let macroCarbs   = Color(red: 0.3, green: 0.5, blue: 0.9)
    static let macroFats    = Color(red: 0.9, green: 0.4, blue: 0.3)
}
