// ============================================
// RecipeDetailView.swift
// ChefDrop
// ============================================
 
import SwiftUI
 
// MARK: - RecipeDetailView
struct RecipeDetailView: View {
 
    let recipe: Recipe
    var viewModel: RecipeViewModel
    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var context
    @Environment(LocaleManager.self) private var localeManager
    @State private var showDeleteConfirmation: Bool = false
    @State private var selectedServings: Int = 1
    private var originalServings: Int { recipe.servings ?? 1 }
 
    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .topLeading) {
                AppColors.background.ignoresSafeArea()
 
                ScrollView {
                    VStack(alignment: .leading, spacing: 0) {
 
                        // MARK: - Header avec image
                        ZStack(alignment: .bottom) {
                            AsyncImage(url: URL(string: recipe.imageUrl ?? "")) { image in
                                image
                                    .resizable()
                                    .scaledToFill()
                                    .frame(width: geo.size.width, height: 280)
                                    .clipped()
                            } placeholder: {
                                AppColors.backgroundSecondary
                                    .frame(width: geo.size.width, height: 280)
                            }
 
                            LinearGradient(
                                colors: [.clear, AppColors.background],
                                startPoint: .top,
                                endPoint: .bottom
                            )
                            .frame(width: geo.size.width, height: 120)
                        }
                        .frame(width: geo.size.width, height: 280)
 
                        VStack(alignment: .leading, spacing: 16) {
 
                            // MARK: - Titre et Icônes
                            VStack(alignment: .leading, spacing: 10) {
                                Text(recipe.title)
                                    .font(.system(size: 24, weight: .bold))
                                    .foregroundColor(AppColors.textPrimary)
 
                                HStack(spacing: 8) {
                                    ForEach(recipe.categories, id: \.self) { category in
                                        Image(category.iconName)
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 28, height: 28)
                                    }
                                }
                            }
 
                            // MARK: - Macros
                            MacrosBoxView(
                                recipe: recipe,
                                originalServings: originalServings,
                                selectedServings: selectedServings,
                                localeManager: localeManager
                            )
                            .onAppear {
                                selectedServings = recipe.servings ?? 1
                            }
 
                            // MARK: - Label macros par portion
                            Text(localeManager.t("* Macros affichées par portion", "* Macros shown per serving"))
                                .font(.system(size: 11))
                                .foregroundColor(.gray)
 
                            // MARK: - Sélecteur de portions
                            PortionsSelectorView(selectedServings: $selectedServings)
                                .id(selectedServings)
 
                            // MARK: - Ingrédients
                            VStack(alignment: .leading, spacing: 12) {
                                Text(localeManager.t("Ingrédients", "Ingredients"))
                                    .font(.system(size: 18, weight: .semibold))
                                    .foregroundColor(AppColors.textPrimary)
 
                                VStack(alignment: .leading, spacing: 10) {
                                    ForEach(scaledIngredients(from: recipe.ingredients, original: originalServings, target: selectedServings), id: \.self) { ingredient in
                                        HStack(alignment: .top, spacing: 12) {
                                            Circle()
                                                .fill(Color(red: 0.83, green: 0.63, blue: 0.09))
                                                .frame(width: 6, height: 6)
                                                .padding(.top, 6)
                                            Text(ingredient)
                                                .font(.system(size: 15))
                                                .foregroundColor(AppColors.textPrimary.opacity(0.85))
                                        }
                                    }
                                }
                            }
 
                            // MARK: - Étapes de préparation
                            VStack(alignment: .leading, spacing: 12) {
                                Text(localeManager.t("Préparation", "Preparation"))
                                    .font(.system(size: 18, weight: .semibold))
                                    .foregroundColor(AppColors.textPrimary)
 
                                VStack(alignment: .leading, spacing: 16) {
                                    ForEach(Array(scaledSteps(from: recipe.steps, original: originalServings, target: selectedServings).enumerated()), id: \.offset) { index, step in
                                        HStack(alignment: .top, spacing: 14) {
                                            Text("\(index + 1)")
                                                .font(.system(size: 13, weight: .bold))
                                                .foregroundColor(.black)
                                                .frame(width: 26, height: 26)
                                                .background(Color(red: 0.83, green: 0.63, blue: 0.09))
                                                .clipShape(Circle())
                                            Text(step)
                                                .font(.system(size: 15))
                                                .foregroundColor(AppColors.textPrimary.opacity(0.85))
                                                .fixedSize(horizontal: false, vertical: true)
                                        }
                                    }
                                }
                            }
 
                            // MARK: - Grille 3 boutons
                            HStack(spacing: 12) {
 
                                Button {
                                    showDeleteConfirmation = true
                                } label: {
                                    Image(systemName: "trash.fill")
                                        .font(.system(size: 18))
                                        .foregroundColor(.white)
                                        .frame(maxWidth: .infinity)
                                        .frame(height: 54)
                                        .background(Color.red)
                                        .cornerRadius(14)
                                }
 
                                Button {
                                    viewModel.toggleFavorite(recipe, context: context)
                                } label: {
                                    Image("icon_favorie")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 24, height: 24)
                                        .frame(maxWidth: .infinity)
                                        .frame(height: 54)
                                        .background(
                                            recipe.isFavorite
                                            ? Color(red: 0.83, green: 0.63, blue: 0.09)
                                            : AppColors.backgroundSecondary
                                        )
                                        .cornerRadius(14)
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 14)
                                                .stroke(
                                                    recipe.isFavorite ? Color.clear : AppColors.separator,
                                                    lineWidth: 1
                                                )
                                        )
                                }
 
                                Button {
                                    viewModel.toggleTryLater(recipe, context: context)
                                } label: {
                                    Image("icon_plus_tard")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 24, height: 24)
                                        .frame(maxWidth: .infinity)
                                        .frame(height: 54)
                                        .background(
                                            recipe.isTryLater
                                            ? Color(red: 0.20, green: 0.50, blue: 0.90)
                                            : AppColors.backgroundSecondary
                                        )
                                        .cornerRadius(14)
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 14)
                                                .stroke(
                                                    recipe.isTryLater ? Color.clear : AppColors.separator,
                                                    lineWidth: 1
                                                )
                                        )
                                }
                            }
                            .padding(.top, 8)
                            .padding(.bottom, 40)
                        }
                        .padding(20)
                        .frame(width: geo.size.width)
                    }
                }
                .frame(width: geo.size.width)
 
                // Bouton retour fixe
                Button(action: { dismiss() }) {
                    Image(systemName: "chevron.left")
                        .font(.system(size: 19, weight: .bold))
                        .foregroundColor(AppColors.textPrimary)
                        .padding(12)
                        .background(.ultraThinMaterial)
                        .clipShape(Circle())
                }
                .padding(.top, 60)
                .padding(.leading, 20)
            }
        }
        .ignoresSafeArea(edges: .top)
        .navigationBarHidden(true)
        .onAppear {
            if selectedServings < 1 { selectedServings = recipe.servings ?? 1 }
        }
        .alert(
            Text(localeManager.t("Supprimer cette recette?", "Delete this recipe?")),
            isPresented: $showDeleteConfirmation
        ) {
            Button(localeManager.t("Supprimer", "Delete"), role: .destructive) {
                viewModel.deleteRecipe(recipe, context: context)
                dismiss()
            }
            Button(localeManager.t("Annuler", "Cancel"), role: .cancel) {}
        } message: {
            Text(localeManager.t(
                "Cette action est irréversible.",
                "This action cannot be undone."
            ))
        }
    }
}
 
// MARK: - MacrosBoxView
struct MacrosBoxView: View {
    let recipe: Recipe
    let originalServings: Int
    let selectedServings: Int
    let localeManager: LocaleManager
 
    private var perServingFactor: Double {
        let denom = originalServings == 0 ? 1 : originalServings
        return Double(denom)
    }
 
    var body: some View {
        HStack(spacing: 0) {
            MacroItemView(
                value: "\(Int(round(Double(recipe.calories) / perServingFactor)))",
                unit: "cal",
                label: localeManager.t("Calories", "Calories"),
                color: Color(red: 0.83, green: 0.63, blue: 0.09)
            )
            DividerLineView()
            MacroItemView(
                value: String(format: "%.0fg", Double(recipe.protein) / perServingFactor),
                unit: "",
                label: localeManager.t("Protéines", "Proteins"),
                color: Color(red: 0.3, green: 0.7, blue: 0.4)
            )
            DividerLineView()
            MacroItemView(
                value: String(format: "%.0fg", Double(recipe.carbs) / perServingFactor),
                unit: "",
                label: localeManager.t("Glucides", "Carbs"),
                color: Color(red: 0.3, green: 0.5, blue: 0.9)
            )
            DividerLineView()
            MacroItemView(
                value: String(format: "%.0fg", Double(recipe.fats) / perServingFactor),
                unit: "",
                label: localeManager.t("Lipides", "Fats"),
                color: Color(red: 0.9, green: 0.4, blue: 0.3)
            )
        }
        .padding(.vertical, 16)
        .background(AppColors.backgroundSecondary)
        .cornerRadius(14)
    }
}
 
// MARK: - MacroItemView
struct MacroItemView: View {
    let value: String
    let unit: String
    let label: String
    let color: Color
 
    var body: some View {
        VStack(spacing: 4) {
            Text(value + unit)
                .font(.system(size: 18, weight: .bold))
                .foregroundColor(color)
            Text(label)
                .font(.system(size: 11))
                .foregroundColor(.gray)
        }
        .frame(maxWidth: .infinity)
    }
}
 
// MARK: - DividerLineView
struct DividerLineView: View {
    var body: some View {
        Rectangle()
            .fill(AppColors.separator)
            .frame(width: 1, height: 40)
    }
}
 
// MARK: - PortionsSelectorView
struct PortionsSelectorView: View {
    @Binding var selectedServings: Int
    @Environment(LocaleManager.self) private var localeManager
 
    var body: some View {
        HStack {
            HStack(spacing: 6) {
                Text(localeManager.t("Nombre de portions", "Servings"))
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundColor(AppColors.textPrimary)
                Text("(\(selectedServings))")
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundColor(AppColors.textPrimary)
                    .monospacedDigit()
            }
            Spacer()
            Stepper(value: $selectedServings, in: 1...20, step: 1) {
                Text("\(selectedServings)")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(AppColors.textPrimary)
                    .frame(minWidth: 36)
            }
            .labelsHidden()
        }
    }
}
 
// MARK: - Helpers
extension RecipeDetailView {
    func scaledIngredients(from ingredients: [String], original: Int, target: Int) -> [String] {
        guard original > 0 else { return ingredients }
        let factor = Double(target) / Double(original)
        return ingredients.map { scaleIngredient($0, factor: factor) }
    }
 
    func scaledSteps(from steps: [String], original: Int, target: Int) -> [String] {
        guard original > 0 else { return steps }
        let factor = Double(target) / Double(original)
        return steps.map { scaleIngredient($0, factor: factor) }
    }
 
    func scaleIngredient(_ text: String, factor: Double) -> String {
        let pattern = "(\\d+\\s*/\\s*\\d+)|(\\d+[\\.,]?\\d*)"
        guard let regex = try? NSRegularExpression(pattern: pattern, options: []) else { return text }
        let ns = NSMutableString(string: text)
        let fullRange = NSRange(location: 0, length: ns.length)
        let matches = regex.matches(in: ns as String, options: [], range: fullRange)
 
        for match in matches.reversed() {
            let fracRange = match.range(at: 1)
            let numRange = match.range(at: 2)
 
            if fracRange.location != NSNotFound {
                let fracStr = ns.substring(with: fracRange)
                let clean = fracStr.replacingOccurrences(of: " ", with: "")
                let parts = clean.split(separator: "/")
                if parts.count == 2, let num = Double(parts[0]), let den = Double(parts[1]), den != 0 {
                    let value = num / den
                    let scaled = value * factor
                    let replacement = formatScaledNumber(scaled)
                    ns.replaceCharacters(in: fracRange, with: replacement)
                }
            } else if numRange.location != NSNotFound {
                let s = ns.substring(with: numRange)
                let normalized = s.replacingOccurrences(of: ",", with: ".")
                if let value = Double(normalized) {
                    let scaled = value * factor
                    let replacement = formatScaledNumber(scaled)
                    ns.replaceCharacters(in: numRange, with: replacement)
                }
            }
        }
 
        return ns as String
    }
 
    func formatScaledNumber(_ value: Double) -> String {
        let rounded = (value * 10).rounded() / 10.0
        if abs(rounded - round(rounded)) < 0.001 {
            return String(Int(round(rounded)))
        } else {
            let useComma = !LocaleManager.shared.isEnglish
            let formatter = NumberFormatter()
            formatter.maximumFractionDigits = 1
            formatter.minimumFractionDigits = 0
            formatter.decimalSeparator = useComma ? "," : "."
            return formatter.string(from: NSNumber(value: rounded)) ?? String(rounded)
        }
    }
}
 
