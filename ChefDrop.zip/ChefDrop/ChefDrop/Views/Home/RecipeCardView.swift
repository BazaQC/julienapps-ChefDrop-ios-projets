/// ============================================
// RecipeCardView.swift
// ChefDrop
// ============================================
import SwiftUI
 
struct RecipeCardView: View {
    
    @Environment(LocaleManager.self) private var localeManager
    let recipe: Recipe
    
    private var caloriesPerServing: Int {
        let servings = max(1, recipe.servings ?? 1)
        return Int(round(Double(recipe.calories) / Double(servings)))
    }
    
    // MARK: - Ordre des catégories par couleur
    var sortedCategories: [RecipeCategory] {
        
        func colorOrder(_ category: RecipeCategory) -> Int {
            switch category {
            case .chicken, .beef, .pork, .fish, .seafood, .duck,
                    .turkey, .eggs, .lamb, .legumineuse, .toffu, .otherProtein:
                return 0
            case .pasta, .rice, .soup, .salad, .sandwich, .pizza, .snack, .bbq,
                    .burger, .tacos, .breakfast, .dessert, .smoothie, .wok,
                    .fromage, .otherMeal:
                return 1
            case .vegetarian, .vegan, .glutenFree, .sansLactose,
                    .sansNoix, .keto, .balanced, .otherStyle:
                return 2
            case .lowFat, .lowCarb, .lowCalorie, .highProtein, .bulk, .other:
                return 3
            }
        }
        
        return recipe.categories.sorted { colorOrder($0) < colorOrder($1) }
    }
    
    @ViewBuilder
    private func goldOutlinedIcon(_ imageName: String) -> some View {
        ZStack {
            Circle()
                .fill(AppColors.background)
                .frame(width: 24, height: 24)
            Circle()
                .stroke(Color(red: 0.83, green: 0.63, blue: 0.09), lineWidth: 0.5)
                .frame(width: 24, height: 24)
            Image(imageName)
                .resizable()
                .scaledToFit()
                .frame(width: 16, height: 16)
                .offset(x: -1)
        }
    }
    
    var body: some View {
        HStack(spacing: 12) {
            
            // MARK: - Image de la recette (Unsplash)
            AsyncImage(url: URL(string: recipe.imageUrl ?? "")) { image in
                image
                    .resizable()
                    .scaledToFill()
            } placeholder: {
                Color.gray.opacity(0.2)
            }
            .frame(width: 50, height: 50)
            .clipShape(RoundedRectangle(cornerRadius: 8))
            
            // MARK: - Contenu
            VStack(alignment: .leading, spacing: 4) {
                
                // Ligne 1 : Titre + icônes favoris + chevron
                HStack {
                    Text(recipe.title)
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundColor(AppColors.textPrimary)
                        .lineLimit(1)
                        .minimumScaleFactor(0.85)
                    
                    Spacer()
                    
                    HStack(spacing: 6) {
                        if recipe.isFavorite {
                            goldOutlinedIcon("icon_favorie")
                        }
                        if recipe.isTryLater {
                            goldOutlinedIcon("icon_plus_tard")
                        }
                    }
                    
                    Image(systemName: "chevron.right")
                        .font(.system(size: 12, weight: .medium))
                        .foregroundColor(.gray.opacity(0.5))
                }
                
                // Ligne 2 : Calories par portion sous le titre
                Text("\(caloriesPerServing) \(localeManager.t("cal / portion", "cal / serving"))")
                    .font(.system(size: 12, weight: .medium))
                    .foregroundColor(Color(red: 0.83, green: 0.63, blue: 0.09))
            }
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 20)  // ← augmenté de 14 à 20
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(AppColors.background)
    }
}
 
