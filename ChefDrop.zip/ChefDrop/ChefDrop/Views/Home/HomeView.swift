// ============================================
// HomeView.swift
// ChefDrop
// ============================================
import SwiftUI
import SwiftData
 
struct HomeView: View {
 
    @Bindable var viewModel: RecipeViewModel
    @Bindable var premiumViewModel: PremiumViewModel
    @Environment(\.modelContext) private var context
    @Environment(LocaleManager.self) private var localeManager
 
    var body: some View {
        NavigationStack {
            ZStack {
                AppColors.background.ignoresSafeArea()
 
                VStack(spacing: 0) {
 
                    // MARK: - Barre de Navigation
                    HStack {
                        // Bouton menu hamburger
                        Button(action: {
                            withAnimation(.spring()) {
                                viewModel.showSideMenu = true
                            }
                        }) {
                            Image(systemName: "line.3.horizontal")
                                .font(.system(size: 22))
                                .foregroundColor(AppColors.textPrimary)
                        }
                        .frame(width: 80, alignment: .leading)
 
                        Spacer()
 
                        Text("ChefDrop")
                            .font(.system(size: 22, weight: .bold))
                            .foregroundColor(AppColors.textPrimary)
 
                        Spacer()
 
                        // Bouton Import — pill gold explicite
                        Button(action: {
                            viewModel.showImport = true
                        }) {
                            HStack(spacing: 5) {
                                Image(systemName: "plus")
                                    .font(.system(size: 12, weight: .bold))
                                Text(localeManager.t("Importer", "Import"))
                                    .font(.system(size: 13, weight: .semibold))
                            }
                            .foregroundColor(.black)
                            .padding(.horizontal, 12)
                            .padding(.vertical, 7)
                            .background(Color(red: 0.83, green: 0.63, blue: 0.09))
                            .clipShape(Capsule())
                            .fixedSize()
                        }
                        .frame(width: 80, alignment: .trailing)
                    }
                    .padding(.horizontal, 20)
                    .padding(.vertical, 16)
 
                    // MARK: - Bandeau Crédits
                    HStack {
                        HStack(spacing: 8) {
                            Image(systemName: "bolt.fill")
                                .font(.system(size: 12))
                                .foregroundColor(Color(red: 0.83, green: 0.63, blue: 0.09))
                            Text(localeManager.t("Crédits restants", "Credits left"))
                                .font(.system(size: 13, weight: .medium))
                                .foregroundColor(Color(red: 0.72, green: 0.51, blue: 0.06))
                        }
                        Spacer()
                        Text("\(premiumViewModel.remainingCredits)")
                            .font(.system(size: 18, weight: .bold))
                            .foregroundColor(
                                premiumViewModel.remainingCredits == 0
                                ? .red
                                : Color(red: 0.83, green: 0.63, blue: 0.09)
                            )
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 9)
                    .background(Color(red: 0.12, green: 0.10, blue: 0.04))
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color(red: 0.4, green: 0.28, blue: 0.04).opacity(0.6), lineWidth: 0.8)
                    )
                    .cornerRadius(10)
                    .padding(.horizontal, 20)
                    .padding(.bottom, 14)
 
                    // MARK: - Titre de la section active
                    sectionTitle
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundColor(AppColors.textPrimary)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.horizontal, 20)
                        .padding(.bottom, 12)
 
                    // MARK: - Liste ou état vide
                    if viewModel.filteredRecipes.isEmpty {
                        EmptyStateView()
                    } else {
                        ScrollView {
                            LazyVStack(spacing: 0) {
                                ForEach(viewModel.filteredRecipes) { recipe in
                                    NavigationLink(destination: RecipeDetailView(
                                        recipe: recipe,
                                        viewModel: viewModel
                                    )) {
                                        RecipeCardView(recipe: recipe)
                                    }
                                    .buttonStyle(PlainButtonStyle())
 
                                    Divider()
                                        .background(AppColors.separator.opacity(0.5))
                                        .padding(.horizontal, 20)
                                }
                            }
                            .padding(.vertical, 8)
                        }
                    }
                }
 
                // MARK: - Overlay du Side Menu
                if viewModel.showSideMenu {
                    Color.black.opacity(0.4)
                        .ignoresSafeArea()
                        .onTapGesture {
                            withAnimation(.spring()) {
                                viewModel.showSideMenu = false
                            }
                        }
                        .zIndex(1)
 
                    SideMenuView(viewModel: viewModel, premiumViewModel: premiumViewModel)
                        .transition(.move(edge: .leading))
                        .zIndex(2)
                }
            }
            .onAppear {
                viewModel.loadRecipes(context: context)
            }
            .onChange(of: viewModel.recipes.count) { _, _ in
                viewModel.loadRecipes(context: context)
            }
        }
    }
 
    // MARK: - Titre dynamique selon le mode actif
    private var sectionTitle: Text {
        switch viewModel.listMode {
        case .favorites:
            return Text(localeManager.t("Favoris", "Favorites"))
        case .tryLater:
            return Text(localeManager.t("À essayer", "Try Later"))
        case .all:
            if let category = viewModel.selectedCategory {
                return Text(category.localizedName(localeManager))
            } else {
                return Text(localeManager.t("Toutes les recettes", "All Recipes"))
            }
        }
    }
 
    // MARK: - Vue état vide
    struct EmptyStateView: View {
        @Environment(LocaleManager.self) private var localeManager
 
        var body: some View {
            VStack(spacing: 16) {
                Spacer()
                Image(systemName: "fork.knife")
                    .font(.system(size: 60))
                    .foregroundColor(.gray)
                Text(localeManager.t("Aucune recette pour l'instant", "No recipes yet"))
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundColor(AppColors.textPrimary)
                Text(localeManager.t(
                    "Appuie sur Importer pour ajouter\nta première recette AI",
                    "Tap Import to add\nyour first AI recipe"
                ))
                    .font(.system(size: 14))
                    .foregroundColor(.gray)
                    .multilineTextAlignment(.center)
                Spacer()
            }
        }
    }
}
 
