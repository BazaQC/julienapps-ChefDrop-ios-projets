// ============================================
// PaywallView.swift
// ChefDrop
//
// Écran affiché quand l'utilisateur n'a plus de crédits.
// Propose 3 packs de crédits consommables (one-time).
// Pas d'abonnement — achat unique, crédits empilables.
// ============================================
 
import SwiftUI
import StoreKit
 
// MARK: - PaywallView
struct PaywallView: View {
 
    @Bindable var premiumViewModel: PremiumViewModel
    @Bindable var viewModel: RecipeViewModel
    @Environment(\.dismiss) private var dismiss
    @Environment(LocaleManager.self) private var localeManager
 
    var body: some View {
        ZStack {
 
            Color(red: 0.08, green: 0.08, blue: 0.08)
                .ignoresSafeArea()
 
            VStack(spacing: 0) {
 
                // MARK: - Bouton Fermer
                HStack {
                    Spacer()
                    Button(action: { dismiss() }) {
                        Image(systemName: "xmark.circle.fill")
                            .font(.system(size: 28))
                            .foregroundColor(Color.gray.opacity(0.6))
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 20)
 
                ScrollView {
                    VStack(spacing: 32) {
 
                        // MARK: - Header
                        VStack(spacing: 12) {
 
                            Image(systemName: "crown.fill")
                                .font(.system(size: 60))
                                .foregroundColor(Color(red: 0.83, green: 0.63, blue: 0.09))
 
                            Text(localeManager.t("Plus de crédits", "No Credits Left"))
                                .font(.system(size: 28, weight: .bold))
                                .foregroundColor(.white)
 
                            Text(localeManager.t(
                                "Vous avez utilisé vos 5 recettes gratuites.\nAchetez un pack pour continuer.",
                                "You've used your 5 free recipes.\nPurchase a pack to continue."
                            ))
                                .font(.system(size: 15))
                                .foregroundColor(.gray)
                                .multilineTextAlignment(.center)
                        }
                        .padding(.top, 20)
 
                        // MARK: - Avantages
                        VStack(spacing: 14) {
                            PremiumFeatureRow(
                                icon: "cart.fill",
                                text: localeManager.t("Achat unique — aucun abonnement", "One-time purchase — no subscription")
                            )
                            PremiumFeatureRow(
                                icon: "plus.circle.fill",
                                text: localeManager.t("Les crédits s'accumulent", "Credits stack up")
                            )
                            PremiumFeatureRow(
                                icon: "icloud.fill",
                                text: localeManager.t("Synchronisation iPhone + iPad", "iPhone + iPad sync")
                            )
                        }
                        .padding(.horizontal, 20)
 
                        // MARK: - Packs de Crédits
                        VStack(spacing: 16) {
 
                            // Pack Starter — 2,99$ / 30 crédits
                            CreditPackButton(
                                pack: .starter,
                                isPopular: false,
                                isLoading: premiumViewModel.isLoading
                            ) {
                                Task {
                                    if let product = premiumViewModel.availableProducts.first(where: {
                                        $0.id == PremiumManager.ProductID.starter
                                    }) {
                                        await premiumViewModel.purchase(product)
                                        if premiumViewModel.remainingCredits > 0 {
                                            dismiss()
                                        }
                                    }
                                }
                            }
 
                            // Pack Chef — 5,99$ / 120 crédits
                            CreditPackButton(
                                pack: .chef,
                                isPopular: true,
                                isLoading: premiumViewModel.isLoading
                            ) {
                                Task {
                                    if let product = premiumViewModel.availableProducts.first(where: {
                                        $0.id == PremiumManager.ProductID.chef
                                    }) {
                                        await premiumViewModel.purchase(product)
                                        if premiumViewModel.remainingCredits > 0 {
                                            dismiss()
                                        }
                                    }
                                }
                            }
 
                            // Pack Pro — 9,99$ / 300 crédits
                            CreditPackButton(
                                pack: .pro,
                                isPopular: false,
                                isLoading: premiumViewModel.isLoading
                            ) {
                                Task {
                                    if let product = premiumViewModel.availableProducts.first(where: {
                                        $0.id == PremiumManager.ProductID.pro
                                    }) {
                                        await premiumViewModel.purchase(product)
                                        if premiumViewModel.remainingCredits > 0 {
                                            dismiss()
                                        }
                                    }
                                }
                            }
                        }
                        .padding(.horizontal, 20)
 
                        // MARK: - Message d'Erreur
                        if let error = premiumViewModel.errorMessage {
                            Text(error)
                                .font(.system(size: 13))
                                .foregroundColor(.red)
                                .multilineTextAlignment(.center)
                                .padding(.horizontal, 20)
                        }
 
                        // MARK: - Mentions Légales
                        Text(localeManager.t(
                            "Achat unique — les crédits n'expirent jamais.",
                            "One-time purchase — credits never expire."
                        ))
                            .font(.system(size: 11))
                            .foregroundColor(Color.gray.opacity(0.6))
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 20)
                            .padding(.bottom, 30)
                    }
                }
            }
        }
    }
}
 
// MARK: - CreditPackButton
struct CreditPackButton: View {
 
    let pack: CreditPack
    let isPopular: Bool
    let isLoading: Bool
    let action: () -> Void
 
    var body: some View {
        Button(action: action) {
            ZStack {
 
                RoundedRectangle(cornerRadius: 14)
                    .fill(
                        LinearGradient(
                            colors: [
                                Color(red: 0.83, green: 0.63, blue: 0.09),
                                Color(red: 0.70, green: 0.50, blue: 0.05)
                            ],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
 
                if isPopular {
                    VStack {
                        HStack {
                            Spacer()
                            Text("⭐ Meilleure valeur")
                                .font(.system(size: 11, weight: .semibold))
                                .foregroundColor(.black)
                                .padding(.horizontal, 10)
                                .padding(.vertical, 4)
                                .background(Color.black.opacity(0.2))
                                .cornerRadius(8)
                                .padding(10)
                        }
                        Spacer()
                    }
                }
 
                if isLoading {
                    ProgressView()
                        .tint(.black)
                } else {
                    HStack {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(pack.rawValue)
                                .font(.system(size: 18, weight: .bold))
                                .foregroundColor(.black)
                            Text(pack.subtitle)
                                .font(.system(size: 13))
                                .foregroundColor(.black.opacity(0.7))
                        }
                        Spacer()
                        Text(pack.price)
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(.black)
                    }
                    .padding(.horizontal, 20)
                }
            }
            .frame(height: 70)
        }
        .disabled(isLoading)
    }
}
 
// MARK: - PremiumFeatureRow (réutilisé depuis l'original)
struct PremiumFeatureRow: View {
 
    let icon: String
    let text: String
 
    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: icon)
                .font(.system(size: 16))
                .foregroundColor(Color(red: 0.83, green: 0.63, blue: 0.09))
                .frame(width: 28)
            Text(text)
                .font(.system(size: 15))
                .foregroundColor(Color.white.opacity(0.85))
            Spacer()
        }
        .padding(.horizontal, 20)
    }
}
  
