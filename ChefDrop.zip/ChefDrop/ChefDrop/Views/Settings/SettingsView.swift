// ============================================
// SettingsView.swift
// ChefDrop
// ============================================
 
import SwiftUI
 
struct SettingsView: View {
    
    @Bindable var premiumViewModel: PremiumViewModel
    @Bindable var viewModel: RecipeViewModel
    @Environment(\.dismiss) private var dismiss
    @Environment(LocaleManager.self) private var localeManager
    @AppStorage("isLightMode") private var isLightMode: Bool = false
    @State private var showPaywall: Bool = false
    @Environment(\.openURL) private var openURL
    
    var body: some View {
        ZStack {
            
            AppColors.background
                .ignoresSafeArea()
            
            VStack(spacing: 0) {
                
                // MARK: - Navigation Bar
                HStack {
                    Button(action: { dismiss() }) {
                        Image(systemName: "chevron.left")
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(AppColors.textPrimary)
                    }
                    Spacer()
                    Text(localeManager.t("Paramètres", "Settings"))
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundColor(AppColors.textPrimary)
                    Spacer()
                    Image(systemName: "chevron.left")
                        .font(.system(size: 16))
                        .foregroundColor(.clear)
                }
                .padding(.horizontal, 20)
                .padding(.vertical, 16)
                
                ScrollView {
                    VStack(spacing: 24) {
                        
                        // MARK: - Section Crédits
                        SettingsSectionView(title: localeManager.t("Mes Crédits", "My Credits")) {
                            HStack(spacing: 14) {
                                Image(systemName: "bolt.fill")
                                    .font(.system(size: 16))
                                    .foregroundColor(AppColors.gold)
                                    .frame(width: 28)
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(localeManager.t("Crédits disponibles", "Available Credits"))
                                        .font(.system(size: 15))
                                        .foregroundColor(AppColors.textPrimary)
                                    Text(localeManager.t(
                                        "1 crédit = 1 recette importée",
                                        "1 credit = 1 imported recipe"
                                    ))
                                        .font(.system(size: 12))
                                        .foregroundColor(AppColors.textSecondary)
                                }
                                Spacer()
                                Text("\(premiumViewModel.remainingCredits)")
                                    .font(.system(size: 22, weight: .bold))
                                    .foregroundColor(
                                        premiumViewModel.remainingCredits == 0
                                        ? .red
                                        : AppColors.gold
                                    )
                            }
                            .padding(.horizontal, 16)
                            .padding(.vertical, 14)
                        }
                        
                        // MARK: - Section Acheter des Crédits
                        SettingsSectionView(title: localeManager.t("Acheter des Crédits", "Buy Credits")) {
                            VStack(spacing: 12) {
                                PremiumSettingsButton(
                                    title: localeManager.t("Starter — +30 recettes", "Starter — +30 recipes"),
                                    price: "2,99$"
                                ) { showPaywall = true }
                                PremiumSettingsButton(
                                    title: localeManager.t("Chef — +120 recettes", "Chef — +120 recipes"),
                                    price: "5,99$"
                                ) { showPaywall = true }
                                PremiumSettingsButton(
                                    title: localeManager.t("Pro — +300 recettes", "Pro — +300 recipes"),
                                    price: "9,99$"
                                ) { showPaywall = true }
                            }
                            .padding(12)
                        }
                        
                        // MARK: - Section Préférences
                        SettingsSectionView(title: localeManager.t("Préférences", "Preferences")) {
                            VStack(spacing: 0) {
                                
                                // Langue FR / EN
                                HStack(spacing: 14) {
                                    Image(systemName: "globe")
                                        .font(.system(size: 15))
                                        .foregroundColor(AppColors.gold)
                                        .frame(width: 28)
                                    Text(localeManager.t("Langue", "Language"))
                                        .font(.system(size: 15))
                                        .foregroundColor(AppColors.textPrimary)
                                    Spacer()
                                    HStack(spacing: 0) {
                                        Button(action: { localeManager.isEnglish = false }) {
                                            Text("FR")
                                                .font(.system(size: 13, weight: .semibold))
                                                .foregroundColor(!localeManager.isEnglish ? .black : AppColors.textSecondary)
                                                .frame(width: 44, height: 30)
                                                .background(!localeManager.isEnglish ? AppColors.gold : Color.clear)
                                                .cornerRadius(8)
                                        }
                                        Button(action: { localeManager.isEnglish = true }) {
                                            Text("EN")
                                                .font(.system(size: 13, weight: .semibold))
                                                .foregroundColor(localeManager.isEnglish ? .black : AppColors.textSecondary)
                                                .frame(width: 44, height: 30)
                                                .background(localeManager.isEnglish ? AppColors.gold : Color.clear)
                                                .cornerRadius(8)
                                        }
                                    }
                                    .background(AppColors.backgroundSecondary)
                                    .cornerRadius(10)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 10)
                                            .stroke(AppColors.separator, lineWidth: 1)
                                    )
                                }
                                .padding(.horizontal, 16)
                                .padding(.vertical, 12)
                                
                                Divider()
                                    .background(AppColors.separator)
                                    .padding(.leading, 52)
                                
                                // Thème Dark / Light
                                SettingsToggleRow(
                                    icon: isLightMode ? "sun.max.fill" : "moon.fill",
                                    title: localeManager.t("Thème", "Theme"),
                                    subtitle: isLightMode ? "Light Mode" : "Dark Mode",
                                    isOn: $isLightMode
                                )
                            }
                        }
                        
                        // MARK: - Section Informations Légales
                        SettingsLinkRow(icon: "doc.text", title: localeManager.t("Conditions d'utilisation", "Terms of Use")) {
                            if let url = URL(string: "https://bazaqc.github.io/ChefDrop/terms.html") {
                                openURL(url)
                            }
                        }

                        Divider()
                            .background(AppColors.separator)
                            .padding(.leading, 52)

                        SettingsLinkRow(icon: "hand.raised.fill", title: localeManager.t("Politique de confidentialité", "Privacy Policy")) {
                            if let url = URL(string: "https://bazaqc.github.io/ChefDrop/privacy.html") {
                                openURL(url)
                            }
                        }
                        
                        
                        Text("ChefDrop v1.0")
                            .font(.system(size: 12))
                            .foregroundColor(AppColors.textSecondary.opacity(0.5))
                            .padding(.bottom, 30)
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 10)
                }
            }
        }
        .sheet(isPresented: $showPaywall) {
            PaywallView(premiumViewModel: premiumViewModel, viewModel: viewModel)
        }
        .preferredColorScheme(isLightMode ? .light : .dark)
    }
}
 
// MARK: - SettingsSectionView
struct SettingsSectionView<Content: View>: View {
    
    let title: String
    @ViewBuilder let content: Content
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title.uppercased())
                .font(.system(size: 11, weight: .semibold))
                .foregroundColor(AppColors.textSecondary)
                .padding(.leading, 4)
            ZStack {
                RoundedRectangle(cornerRadius: 14)
                    .fill(AppColors.backgroundSecondary)
                content
            }
        }
    }
}
 
// MARK: - SettingsToggleRow
struct SettingsToggleRow: View {
    
    let icon: String
    let title: String
    let subtitle: String
    @Binding var isOn: Bool
    
    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: icon)
                .font(.system(size: 15))
                .foregroundColor(AppColors.gold)
                .frame(width: 28)
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.system(size: 15))
                    .foregroundColor(AppColors.textPrimary)
                Text(subtitle)
                    .font(.system(size: 12))
                    .foregroundColor(AppColors.textSecondary)
            }
            Spacer()
            Toggle("", isOn: $isOn)
                .tint(AppColors.gold)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
    }
}
 
// MARK: - SettingsLinkRow
struct SettingsLinkRow: View {
    
    let icon: String
    let title: String
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack(spacing: 14) {
                Image(systemName: icon)
                    .font(.system(size: 15))
                    .foregroundColor(AppColors.gold)
                    .frame(width: 28)
                Text(title)
                    .font(.system(size: 15))
                    .foregroundColor(AppColors.textPrimary)
                Spacer()
                Image(systemName: "chevron.right")
                    .font(.system(size: 12))
                    .foregroundColor(AppColors.textSecondary)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 14)
        }
    }
}
 
// MARK: - PremiumSettingsButton
struct PremiumSettingsButton: View {
    
    let title: String
    let price: String
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack {
                Image(systemName: "bolt.fill")
                    .font(.system(size: 14))
                    .foregroundColor(.black)
                Text(title)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(.black)
                Spacer()
                Text(price)
                    .font(.system(size: 13, weight: .medium))
                    .foregroundColor(.black.opacity(0.7))
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 14)
            .background(
                LinearGradient(
                    colors: [
                        Color(red: 0.83, green: 0.63, blue: 0.09),
                        Color(red: 0.70, green: 0.50, blue: 0.05)
                    ],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            )
            .cornerRadius(12)
        }
    }
}
