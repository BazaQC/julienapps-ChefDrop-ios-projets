// ============================================
// RecipeConfirmationView.swift
// ChefDrop
// ============================================
 
import SwiftUI
 
// MARK: - RecipeConfirmationView
struct RecipeConfirmationView: View {
 
    let localeManager: LocaleManager
    @State private var editedTitle: String
    @State private var isFavorite: Bool = false
    @State private var isTryLater: Bool = false
    let recipe: Recipe
    let onSave: (Recipe) -> Void
    let onCancel: () -> Void
 
    init(
        recipe: Recipe,
        localeManager: LocaleManager,
        onSave: @escaping (Recipe) -> Void,
        onCancel: @escaping () -> Void
    ) {
        self.recipe = recipe
        self.localeManager = localeManager
        self.onSave = onSave
        self.onCancel = onCancel
        _editedTitle = State(initialValue: recipe.title)
    }
 
    var body: some View {
        ZStack {
            // MARK: - Gradient overlay
            VStack {
                Spacer()
                LinearGradient(
                    colors: [.clear, AppColors.background],
                    startPoint: .top,
                    endPoint: .bottom
                )
                .frame(height: 300)
            }
            .ignoresSafeArea()
 
            // MARK: - Content
            ScrollView {
                VStack(spacing: 24) {
 
                    // Icône succès
                    ZStack {
                        Circle()
                            .fill(Color(red: 0.83, green: 0.63, blue: 0.09).opacity(0.15))
                            .frame(width: 80, height: 80)
                        Image(systemName: "checkmark.circle.fill")
                            .font(.system(size: 44))
                            .foregroundColor(Color(red: 0.83, green: 0.63, blue: 0.09))
                    }
                    .padding(.top, 40)
 
                    // Titre section
                    VStack(spacing: 6) {
                        Text(localeManager.t("Recette détectée! ✨", "Recipe detected! ✨"))
                            .font(.system(size: 20, weight: .bold))
                            .foregroundColor(AppColors.textPrimary)
                        Text(localeManager.t(
                            "Confirme ou modifie le nom avant de sauvegarder",
                            "Confirm or edit the name before saving"
                        ))
                        .font(.system(size: 14))
                        .foregroundColor(.gray)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 20)
                    }
 
                    // Champ titre modifiable
                    VStack(alignment: .leading, spacing: 8) {
                        Text(localeManager.t("Nom de la recette", "Recipe name"))
                            .font(.system(size: 13, weight: .medium))
                            .foregroundColor(.gray)
                            .padding(.horizontal, 20)
 
                        TextField("", text: $editedTitle)
                            .font(.system(size: 18, weight: .semibold))
                            .foregroundColor(AppColors.textPrimary)
                            .padding(16)
                            .background(AppColors.backgroundSecondary)
                            .cornerRadius(12)
                            .padding(.horizontal, 20)
                    }
 
                    // Infos détectées
                    VStack(spacing: 0) {
                        InfoRow(
                            icon: "tag.fill",
                            label: localeManager.t("Catégorie", "Category"),
                            value: recipe.category.localizedName(localeManager)
                        )
                        Divider().background(Color.gray.opacity(0.2))
                        InfoRow(
                            icon: "flame.fill",
                            label: localeManager.t("Calories", "Calories"),
                            value: "\(Int(round(Double(recipe.calories) / Double(max(1, recipe.servings ?? 1))))) cal / \(localeManager.t("portion", "serving"))"
                        )
                        Divider().background(Color.gray.opacity(0.2))
                        InfoRow(
                            icon: "list.bullet",
                            label: localeManager.t("Ingrédients", "Ingredients"),
                            value: "\(recipe.ingredients.count)"
                        )
                        Divider().background(Color.gray.opacity(0.2))
                        InfoRow(
                            icon: "number",
                            label: localeManager.t("Étapes", "Steps"),
                            value: "\(recipe.steps.count)"
                        )
                    }
                    .background(AppColors.backgroundSecondary)
                    .cornerRadius(12)
                    .padding(.horizontal, 20)
 
                    // Toggles Favoris / À essayer
                    VStack(spacing: 0) {
                        HStack(spacing: 14) {
                            Image("icon_favorie")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 20, height: 20)
                                .foregroundColor(isFavorite ? Color(red: 0.83, green: 0.63, blue: 0.09) : .gray)
                                .frame(width: 28)
                            Text(localeManager.t("Ajouter aux favoris", "Add to favorites"))
                                .font(.system(size: 15))
                                .foregroundColor(AppColors.textPrimary)
                            Spacer()
                            Toggle("", isOn: $isFavorite)
                                .tint(Color(red: 0.83, green: 0.63, blue: 0.09))
                        }
                        .padding(.horizontal, 16)
                        .padding(.vertical, 12)
 
                        Divider().background(Color.gray.opacity(0.2))
 
                        HStack(spacing: 14) {
                            Image("icon_plus_tard")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 20, height: 20)
                                .foregroundColor(isTryLater ? Color(red: 0.83, green: 0.63, blue: 0.09) : .gray)
                                .frame(width: 28)
                            Text(localeManager.t("À essayer plus tard", "Try later"))
                                .font(.system(size: 15))
                                .foregroundColor(AppColors.textPrimary)
                            Spacer()
                            Toggle("", isOn: $isTryLater)
                                .tint(Color(red: 0.83, green: 0.63, blue: 0.09))
                        }
                        .padding(.horizontal, 16)
                        .padding(.vertical, 12)
                    }
                    .background(AppColors.backgroundSecondary)
                    .cornerRadius(12)
                    .padding(.horizontal, 20)
 
                    // Boutons
                    VStack(spacing: 12) {
                        Button {
                            recipe.title = editedTitle.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
                                ? recipe.title
                                : editedTitle.trimmingCharacters(in: .whitespacesAndNewlines)
                            recipe.isFavorite = isFavorite
                            recipe.isTryLater = isTryLater
                            onSave(recipe)
                        } label: {
                            Text(localeManager.t("Sauvegarder la recette", "Save Recipe"))
                                .font(.system(size: 16, weight: .semibold))
                                .foregroundColor(.black)
                                .frame(maxWidth: .infinity)
                                .frame(height: 54)
                                .background(Color(red: 0.83, green: 0.63, blue: 0.09))
                                .cornerRadius(14)
                        }
 
                        Button {
                            onCancel()
                        } label: {
                            Text(localeManager.t("Annuler", "Cancel"))
                                .font(.system(size: 16))
                                .foregroundColor(.gray)
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.bottom, 40)
                }
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .ignoresSafeArea()
        // ✅ Background en dehors du ZStack — fix fullscreen iPad
        .background(
            Group {
                if let url = URL(string: recipe.imageUrl ?? "") {
                    AsyncImage(url: url) { image in
                        image
                            .resizable()
                            .scaledToFill()
                    } placeholder: {
                        AppColors.background
                    }
                } else {
                    AppColors.background
                }
            }
            .ignoresSafeArea()
        )
    }
}
