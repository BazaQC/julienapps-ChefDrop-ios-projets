// ============================================
// ImportSupportViews.swift
// ChefDrop
// ============================================
 
import SwiftUI
 
// MARK: - InfoRow
struct InfoRow: View {
    let icon: String
    let label: String
    let value: String
 
    var body: some View {
        HStack {
            Image(systemName: icon)
                .font(.system(size: 14))
                .foregroundColor(Color(red: 0.83, green: 0.63, blue: 0.09))
                .frame(width: 24)
            Text(label)
                .font(.system(size: 14))
                .foregroundColor(.gray)
            Spacer()
            Text(value)
                .font(.system(size: 14, weight: .semibold))
                .foregroundColor(AppColors.textPrimary)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
    }
}
 
// MARK: - PasteZone
struct PasteZone: View {
    let geo: GeometryProxy
    @Binding var pastedText: String
    @Binding var lastPastedText: String
    let localeManager: LocaleManager
 
    var body: some View {
        VStack(spacing: 10) {
            ZStack(alignment: .topLeading) {
                RoundedRectangle(cornerRadius: 16)
                    .fill(AppColors.backgroundSecondary)
                    .overlay(
                        RoundedRectangle(cornerRadius: 16)
                            .strokeBorder(
                                pastedText.isEmpty
                                ? Color.gray.opacity(0.3)
                                : Color(red: 0.83, green: 0.63, blue: 0.09).opacity(0.7),
                                lineWidth: 1.5
                            )
                    )
 
                if pastedText.isEmpty {
                    VStack(spacing: 12) {
                        Image(systemName: "doc.text.below.ecg")
                            .font(.system(size: 32))
                            .foregroundColor(.gray.opacity(0.4))
                        Text(localeManager.t(
                            "Copiez une recette depuis l'IA de votre choix et collez-la ici.",
                            "Copy a recipe from your AI tool of choice and paste it here."
                        ))
                        .font(.system(size: 14))
                        .foregroundColor(Color.gray.opacity(0.6))
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 20)
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    VStack(alignment: .leading, spacing: 14) {
                        HStack(spacing: 10) {
                            Image(systemName: "checkmark.circle.fill")
                                .font(.system(size: 20))
                                .foregroundColor(Color(red: 0.83, green: 0.63, blue: 0.09))
                            Text(localeManager.t("Recette prête à convertir", "Recipe ready to convert"))
                                .font(.system(size: 15, weight: .semibold))
                                .foregroundColor(AppColors.textPrimary)
                        }
 
                        Divider()
                            .background(Color.gray.opacity(0.2))
 
                        VStack(alignment: .leading, spacing: 8) {
                            HStack(spacing: 8) {
                                Image(systemName: "checkmark.circle.fill")
                                    .font(.system(size: 13))
                                    .foregroundColor(Color(red: 0.83, green: 0.63, blue: 0.09))
                                Text(localeManager.t("Texte collé avec succès", "Text pasted successfully"))
                                    .font(.system(size: 13, weight: .medium))
                                    .foregroundColor(AppColors.textPrimary)
                            }
                            HStack(spacing: 8) {
                                Image(systemName: "arrow.right.circle.fill")
                                    .font(.system(size: 13))
                                    .foregroundColor(.gray)
                                Text(localeManager.t(
                                    "Appuyer sur Convertir pour analyser votre recette",
                                    "Tap Convert to analyze your recipe"
                                ))
                                    .font(.system(size: 13))
                                    .foregroundColor(.gray)
                            }
                        }
                    }
                    .padding(20)
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
                }
 
                TextEditor(text: $pastedText)
                    .scrollContentBackground(.hidden)
                    .background(Color.clear)
                    .foregroundColor(Color.clear)
                    .tint(Color.clear)
                    .font(.system(size: 14))
                    .padding(10)
                    .allowsHitTesting(pastedText.isEmpty)
            }
            .frame(width: geo.size.width - 36, height: 180)
 
            if !pastedText.isEmpty {
                Button {
                    if lastPastedText.isEmpty {
                        pastedText = ""
                    } else {
                        pastedText = lastPastedText
                        lastPastedText = ""
                    }
                } label: {
                    HStack(spacing: 6) {
                        Image(systemName: lastPastedText.isEmpty ? "trash" : "arrow.uturn.backward")
                            .font(.system(size: 12))
                        Text(lastPastedText.isEmpty
                             ? localeManager.t("Effacer", "Clear")
                             : localeManager.t("Annuler", "Undo"))
                            .font(.system(size: 13, weight: .medium))
                    }
                    .foregroundColor(lastPastedText.isEmpty ? .red.opacity(0.9) : .orange.opacity(0.9))
                    .padding(.horizontal, 14)
                    .padding(.vertical, 7)
                    .background(
                        Capsule()
                            .fill(lastPastedText.isEmpty
                                  ? Color.red.opacity(0.12)
                                  : Color.orange.opacity(0.12))
                    )
                    .overlay(
                        Capsule()
                            .strokeBorder(
                                lastPastedText.isEmpty
                                ? Color.red.opacity(0.3)
                                : Color.orange.opacity(0.3),
                                lineWidth: 1
                            )
                    )
                }
                .frame(width: geo.size.width - 36, alignment: .trailing)
            }
        }
    }
}
 
