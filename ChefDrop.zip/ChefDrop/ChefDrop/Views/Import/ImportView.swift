
// ============================================
// ImportView.swift
// ChefDrop
// ============================================
 
import SwiftUI
import UIKit
 
// MARK: - ImportView
struct ImportView: View {
 
    var viewModel: RecipeViewModel
    var premiumViewModel: PremiumViewModel
    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var context
    @Environment(LocaleManager.self) private var localeManager
 
    @State private var pastedText: String = ""
    @State private var lastPastedText: String = ""
    @State private var isLoading: Bool = false
    @State private var errorMessage: String? = nil
    @State private var parsedRecipe: Recipe? = nil
    @State private var showConfirmation: Bool = false
 
    var body: some View {
        NavigationStack {
            GeometryReader { geo in
                ZStack {
                    Image("import_header")
                        .resizable()
                        .scaledToFill()
                        .frame(width: geo.size.width, height: geo.size.height)
                        .clipped()
                        .ignoresSafeArea()
 
                    VStack {
                        Spacer()
                        LinearGradient(
                            colors: [.clear, AppColors.background],
                            startPoint: .top,
                            endPoint: .bottom
                        )
                        .frame(height: geo.size.height * 0.65)
                    }
                    .ignoresSafeArea()
 
                    VStack {
                        Spacer()
 
                        VStack(spacing: 16) {
 
                            // MARK: - Zone de collage
                            PasteZone(
                                geo: geo,
                                pastedText: $pastedText,
                                lastPastedText: $lastPastedText,
                                localeManager: localeManager
                            )
 
                            if let error = errorMessage {
                                Text(error)
                                    .font(.system(size: 13))
                                    .foregroundColor(.red)
                                    .frame(width: geo.size.width - 36, alignment: .leading)
                            }
 
                            VStack(spacing: 12) {
                                if UIPasteboard.general.hasStrings && pastedText.isEmpty {
                                    Button {
                                        lastPastedText = pastedText
                                        pastedText = UIPasteboard.general.string ?? ""
                                    } label: {
                                        HStack(spacing: 8) {
                                            Image(systemName: "doc.on.clipboard")
                                                .font(.system(size: 15))
                                            Text(localeManager.t("Coller la recette", "Paste Recipe"))
                                                .font(.system(size: 16, weight: .semibold))
                                        }
                                        .foregroundColor(.black)
                                        .frame(width: geo.size.width - 36)
                                        .frame(height: 54)
                                        .background(Color(red: 0.83, green: 0.63, blue: 0.09))
                                        .cornerRadius(14)
                                    }
                                }
 
                                Button {
                                    Task { await convertRecipe() }
                                } label: {
                                    ZStack {
                                        if isLoading {
                                            ProgressView().tint(.black)
                                        } else {
                                            Text(localeManager.t("Convertir en recette", "Convert to Recipe"))
                                                .font(.system(size: 16, weight: .semibold))
                                                .foregroundColor(
                                                    pastedText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
                                                    ? Color.black.opacity(0.4)
                                                    : .black
                                                )
                                        }
                                    }
                                    .frame(width: geo.size.width - 36)
                                    .frame(height: 54)
                                    .background(
                                        pastedText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
                                        ? Color(red: 0.83, green: 0.63, blue: 0.09).opacity(0.3)
                                        : Color(red: 0.83, green: 0.63, blue: 0.09)
                                    )
                                    .cornerRadius(14)
                                }
                                .disabled(pastedText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || isLoading)
                            }
                        }
 
                        Spacer()
                    }
                }
            }
            .ignoresSafeArea()
            .navigationTitle(localeManager.t("Importer", "Import Recipe"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbarBackground(.ultraThinMaterial, for: .navigationBar)
            .toolbarColorScheme(.dark, for: .navigationBar)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button(localeManager.t("Annuler", "Cancel")) { dismiss() }
                        .foregroundColor(.white)
                }
            }
            // ✅ fullScreenCover pour iPhone + iPad fullscreen
            .fullScreenCover(isPresented: $showConfirmation) {
                if let recipe = parsedRecipe {
                    RecipeConfirmationView(
                        recipe: recipe,
                        localeManager: localeManager,
                        onSave: { finalRecipe in
                            viewModel.saveRecipe(finalRecipe, context: context, premiumViewModel: premiumViewModel)
                            showConfirmation = false
                            dismiss()
                        },
                        onCancel: {
                            showConfirmation = false
                            parsedRecipe = nil
                            pastedText = ""
                            lastPastedText = ""
                        }
                    )
                }
            }
        }
    }
 
    private func convertRecipe() async {
        guard !pastedText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
        errorMessage = nil
        isLoading = true
 
        guard let recipe = await viewModel.parser.parseRecipe(from: pastedText, localeManager: localeManager) else {
            isLoading = false
            errorMessage = localeManager.t(
                "Impossible d'importer la recette. Réessaie.",
                "Unable to import the recipe. Please try again."
            )
            return
        }
 
        do {
            let imageURL = try await SupabaseImageService.shared.fetchImage(for: recipe.title)
            recipe.imageUrl = imageURL
        } catch {
            print("⚠️ Impossible de générer l'image :", error)
        }
 
        isLoading = false
        parsedRecipe = recipe
        showConfirmation = true
    }
}
 
