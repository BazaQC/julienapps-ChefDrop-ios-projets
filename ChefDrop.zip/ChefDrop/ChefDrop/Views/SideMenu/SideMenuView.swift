// ============================================
// SideMenuView.swift
// ChefDrop
// ============================================
import SwiftUI

struct SideMenuView: View {

    @Bindable var viewModel: RecipeViewModel
    @Bindable var premiumViewModel: PremiumViewModel
    @State private var showSettings: Bool = false
    @Environment(LocaleManager.self) private var localeManager

    // MARK: - Listes de catégories par section
    // 🔴 Protéines — ligne rouge
    let proteinCategories: [RecipeCategory] = [
        .chicken, .beef, .pork, .fish, .seafood,
        .turkey, .eggs, .lamb, .duck, .legumineuse, .toffu, .otherProtein
    ]

    // 🟡 Plats — ligne jaune
    let mealCategories: [RecipeCategory] = [
        .pasta, .rice, .soup, .salad, .sandwich, .pizza,
        .burger, .tacos, .breakfast, .dessert, .smoothie, .wok,
        .snack, .bbq, .fromage, .otherMeal
    ]

    // 🟢 Style — ligne verte
    let styleCategories: [RecipeCategory] = [
        .vegetarian, .vegan, .glutenFree,
        .sansLactose, .sansNoix, .keto, .balanced, .otherStyle
    ]

    // Vrai si au moins un filtre est actif (catégorie ou fitness)
    var hasActiveFilters: Bool {
        !viewModel.selectedCategories.isEmpty || !viewModel.selectedFitnessFilters.isEmpty
    }

    var body: some View {
        ZStack(alignment: .leading) {
            Color.clear.ignoresSafeArea()

            VStack(alignment: .leading, spacing: 0) {

                // MARK: - Header
                HStack {
                    Text(localeManager.t("Filtres", "Filters"))
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(AppColors.textPrimary)

                    Spacer()

                    if hasActiveFilters {
                        Button {
                            viewModel.clearAllFilters()
                        } label: {
                            Text(localeManager.t("Réinitialiser", "Reset"))
                                .font(.system(size: 13))
                                .foregroundColor(Color(red: 0.83, green: 0.63, blue: 0.09))
                        }
                    }
                }
                .padding(.top, 60)
                .padding(.horizontal, 24)
                .padding(.bottom, 16)

                ScrollView(showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 24) {

                        // MARK: - Toutes les recettes
                        Button {
                            viewModel.clearAllFilters()
                            viewModel.listMode = .all
                        } label: {
                            HStack(spacing: 10) {
                                Image(systemName: "square.grid.2x2.fill")
                                    .font(.system(size: 13))
                                Text(localeManager.t("Toutes les recettes", "All Recipes"))
                                    .font(.system(size: 15, weight: .semibold))
                                Spacer()
                                if viewModel.listMode == .all && !hasActiveFilters {
                                    Image(systemName: "checkmark")
                                        .font(.system(size: 12, weight: .bold))
                                }
                            }
                            .foregroundColor(viewModel.listMode == .all && !hasActiveFilters
                                ? Color(red: 0.83, green: 0.63, blue: 0.09) : .gray)
                            .padding(.horizontal, 24)
                        }

                        // MARK: - Favoris
                        Button {
                            viewModel.listMode = .favorites
                        } label: {
                            HStack(spacing: 10) {
                                Image("icon_favorie")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 20, height: 20)
                                Text(localeManager.t("Favoris", "Favorites"))
                                    .font(.system(size: 15, weight: .semibold))
                                Spacer()
                                if viewModel.listMode == .favorites {
                                    Image(systemName: "checkmark")
                                        .font(.system(size: 12, weight: .bold))
                                }
                            }
                            .foregroundColor(viewModel.listMode == .favorites
                                ? Color(red: 0.83, green: 0.63, blue: 0.09) : .gray)
                            .padding(.horizontal, 24)
                        }

                        // MARK: - À essayer
                        Button {
                            viewModel.listMode = .tryLater
                        } label: {
                            HStack(spacing: 10) {
                                Image("icon_plus_tard")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 20, height: 20)
                                Text(localeManager.t("Recettes à essayer", "Try Later"))
                                    .font(.system(size: 15, weight: .semibold))
                                Spacer()
                                if viewModel.listMode == .tryLater {
                                    Image(systemName: "checkmark")
                                        .font(.system(size: 12, weight: .bold))
                                }
                            }
                            .foregroundColor(viewModel.listMode == .tryLater
                                ? Color(red: 0.83, green: 0.63, blue: 0.09) : .gray)
                            .padding(.horizontal, 24)
                        }

                        Divider()
                            .background(AppColors.separator)
                            .padding(.horizontal, 24)

                        // MARK: - Protéines (ligne rouge)
                        FilterGroupView(
                            title: localeManager.t("Protéine principale", "Main Protein"),
                            categories: proteinCategories,
                            viewModel: viewModel,
                            localeManager: localeManager,
                            accentColor: Color(red: 0.85, green: 0.18, blue: 0.18)
                        )

                        // MARK: - Plats (ligne jaune)
                        FilterGroupView(
                            title: localeManager.t("Type de plat", "Meal Type"),
                            categories: mealCategories,
                            viewModel: viewModel,
                            localeManager: localeManager,
                            accentColor: Color(red: 0.95, green: 0.75, blue: 0.10)
                        )

                        // MARK: - Style (ligne verte)
                        FilterGroupView(
                            title: localeManager.t("Style", "Style"),
                            categories: styleCategories,
                            viewModel: viewModel,
                            localeManager: localeManager,
                            accentColor: Color(red: 0.20, green: 0.72, blue: 0.35)
                        )

                        Divider()
                            .background(AppColors.separator)
                            .padding(.horizontal, 24)

                        // MARK: - Objectif Fitness (ligne bleue)
                        FitnessFilterGroupView(
                            viewModel: viewModel,
                            localeManager: localeManager
                        )

                        Spacer().frame(height: 100)
                    }
                }

                // MARK: - Footer
                VStack(spacing: 0) {
                    Divider().background(AppColors.separator)

                    HStack {
                        Button {
                            showSettings = true
                        } label: {
                            HStack(spacing: 8) {
                                Image(systemName: "gear")
                                    .font(.system(size: 16))
                                Text(localeManager.t("Paramètres", "Settings"))
                                    .font(.system(size: 15))
                            }
                            .foregroundColor(.gray)
                        }

                        Spacer()

                        Button {
                            viewModel.applyAndClose()
                        } label: {
                            Text(localeManager.t("Appliquer", "Apply"))
                                .font(.system(size: 15, weight: .semibold))
                                .foregroundColor(.black)
                                .padding(.horizontal, 20)
                                .padding(.vertical, 10)
                                .background(Color(red: 0.83, green: 0.63, blue: 0.09))
                                .cornerRadius(10)
                        }
                    }
                    .padding(.horizontal, 24)
                    .padding(.vertical, 16)
                    .padding(.bottom, 20)
                }
                .background(AppColors.backgroundMenu)
            }
            .frame(width: {
#if os(iOS)
                return UIDevice.current.userInterfaceIdiom == .pad ? 400 : 320
#else
                return 400
#endif
            }())
            .background(AppColors.backgroundMenu)
            .ignoresSafeArea()
        }
        .sheet(isPresented: $showSettings) {
            SettingsView(premiumViewModel: premiumViewModel, viewModel: viewModel)
        }
    }
}

// MARK: - FilterGroupView
struct FilterGroupView: View {

    let title: String
    let categories: [RecipeCategory]
    let viewModel: RecipeViewModel
    let localeManager: LocaleManager
    var accentColor: Color = .red

    var body: some View {
        HStack(alignment: .top, spacing: 0) {

            Rectangle()
                .fill(accentColor)
                .frame(width: 3)
                .padding(.leading, 24)
                .padding(.top, 2)

            VStack(alignment: .leading, spacing: 10) {

                Text(title)
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundColor(.gray)
                    .padding(.leading, 12)

                LazyVGrid(columns: [
                    GridItem(.flexible(), spacing: 8),
                    GridItem(.flexible(), spacing: 8)
                ], spacing: 8) {
                    ForEach(categories, id: \.self) { category in
                        FilterChip(
                            title: category.localizedName(localeManager),
                            iconName: category.iconName,
                            isSelected: viewModel.selectedCategories.contains(category)
                        ) {
                            viewModel.toggleCategory(category)
                        }
                    }
                }
                .padding(.leading, 12)
                .padding(.trailing, 24)
            }
            .frame(maxWidth: .infinity)
        }
    }
}

// MARK: - FitnessFilterGroupView
struct FitnessFilterGroupView: View {

    let viewModel: RecipeViewModel
    let localeManager: LocaleManager

    func fitnessLabel(_ filter: FitnessFilter) -> String {
        switch filter {
        case .highProtein: return localeManager.t("Haute protéine", "High Protein")
        case .lowCalorie:  return localeManager.t("Faible calorie", "Low Calorie")
        case .bulk:        return localeManager.t("Prise de masse", "Bulk / Gain")
        case .lowFat:      return localeManager.t("Faible gras", "Low Fat")
        case .lowCarb:     return localeManager.t("Faible glucide", "Low Carb")
        }
    }

    func fitnessIcon(_ filter: FitnessFilter) -> String {
        switch filter {
        case .highProtein: return "icon_proteine"
        case .lowCalorie:  return "icon_low_calorie"
        case .bulk:        return "icon_prise_de_masse"
        case .lowFat:      return "icon_low_fat"
        case .lowCarb:     return "icon_low_carb"
        }
    }

    var body: some View {
        HStack(alignment: .top, spacing: 0) {

            Rectangle()
                .fill(Color(red: 0.20, green: 0.50, blue: 0.90))
                .frame(width: 3)
                .padding(.leading, 24)
                .padding(.top, 2)

            VStack(alignment: .leading, spacing: 10) {

                Text(localeManager.t("Objectif fitness", "Fitness Goal"))
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundColor(.gray)
                    .padding(.leading, 12)

                LazyVGrid(columns: [
                    GridItem(.flexible(), spacing: 8),
                    GridItem(.flexible(), spacing: 8)
                ], spacing: 8) {
                    ForEach(FitnessFilter.allCases, id: \.self) { filter in
                        FilterChip(
                            title: fitnessLabel(filter),
                            iconName: fitnessIcon(filter),
                            isSelected: viewModel.selectedFitnessFilters.contains(filter)
                        ) {
                            viewModel.toggleFitnessFilter(filter)
                        }
                    }

                    FilterChip(
                        title: localeManager.t("Autre", "Other"),
                        iconName: "icon_autre_bleu",
                        isSelected: viewModel.selectedCategories.contains(.other)
                    ) {
                        viewModel.toggleCategory(.other)
                    }
                }
                .padding(.leading, 12)
                .padding(.trailing, 24)
            }
            .frame(maxWidth: .infinity)
        }
    }
}

// MARK: - FilterChip
struct FilterChip: View {

    let title: String
    let iconName: String
    let isSelected: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 6) {
                Image(iconName)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 22, height: 22)

                Text(title)
                    .font(.system(size: 13, weight: isSelected ? .semibold : .regular))
                    .foregroundColor(isSelected ? .black : AppColors.textPrimary)
                    .lineLimit(2)
                    .minimumScaleFactor(0.75)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 10)
            .frame(minHeight: 44)
            .background(
                isSelected
                ? Color(red: 0.83, green: 0.63, blue: 0.09)
                : AppColors.backgroundSecondary
            )
            .cornerRadius(12)
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(
                        isSelected ? Color.clear : AppColors.separator,
                        lineWidth: 1
                    )
            )
        }
    }
}
