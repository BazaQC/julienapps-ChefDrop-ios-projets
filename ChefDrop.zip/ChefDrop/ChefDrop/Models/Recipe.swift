// ============================================
// Recipe.swift
// ChefDrop
// ============================================
import Foundation
import SwiftData

// MARK: - Catégorie principale
enum RecipeCategory: String, CaseIterable, Codable {
    // 🔴 Protéines
    case chicken      = "Chicken"
    case beef         = "Beef"
    case pork         = "Pork"
    case fish         = "Fish"
    case seafood      = "Seafood"
    case turkey       = "Turkey"
    case eggs         = "Eggs"
    case lamb         = "Lamb"
    case duck         = "Duck"          // ← nouveau
    case legumineuse  = "Legumineuse"
    case toffu        = "Toffu"
    case otherProtein = "OtherProtein"
    // 🟡 Plats
    case pasta        = "Pasta"
    case rice         = "Rice"
    case soup         = "Soup"
    case salad        = "Salad"
    case sandwich     = "Sandwich"
    case pizza        = "Pizza"
    case burger       = "Burger"
    case tacos        = "Tacos"
    case breakfast    = "Breakfast"
    case dessert      = "Dessert"
    case smoothie     = "Smoothie"
    case wok          = "Wok"
    case snack        = "Snack"         // ← nouveau
    case bbq          = "BBQ"           // ← nouveau (remplace stew)
    case fromage      = "Fromage"
    case otherMeal    = "OtherMeal"
    // 🟢 Styles
    case vegetarian   = "Vegetarian"
    case vegan        = "Vegan"
    case glutenFree   = "GlutenFree"
    case sansLactose  = "SansLactose"
    case sansNoix     = "SansNoix"
    case otherStyle   = "OtherStyle"
    // 🟢 Régime (affiché dans Style)
    case keto         = "Keto"
    case balanced     = "Balanced"
    // � Fitness
    case highProtein  = "HighProtein"
    case lowCalorie   = "LowCalorie"
    case lowFat       = "LowFat"
    case lowCarb      = "LowCarb"
    case bulk         = "Bulk"
    case other        = "Other"          // ← déjà là, le garder en dernier
}

// MARK: - Filtre Fitness
enum FitnessFilter: String, CaseIterable {
    case highProtein = "HighProtein"
    case lowCalorie  = "LowCalorie"
    case bulk        = "Bulk"
    case lowFat      = "LowFat"
    case lowCarb     = "LowCarb"        // ← nouveau

    func matches(_ recipe: Recipe) -> Bool {
        switch self {
        case .highProtein: return recipe.protein >= 30
        case .lowCalorie:  return recipe.calories <= 400
        case .bulk:        return recipe.calories >= 500 && recipe.protein >= 30
        case .lowFat:      return recipe.fats <= 10
        case .lowCarb:     return recipe.carbs <= 30  // ← nouveau
        }
    }
}

// MARK: - Mode liste (Toutes / Favoris / À essayer)
enum RecipeListMode {
    case all
    case favorites
    case tryLater
}

// MARK: - Modèle Recipe
@Model
class Recipe {
    var id: UUID
    var title: String
    var categories: [RecipeCategory]
    var createdAt: Date
    var ingredients: [String]
    var steps: [String]
    var calories: Int
    var protein: Double
    var carbs: Double
    var fats: Double
    var isFavorite: Bool = false        // ← nouveau
    var isTryLater: Bool = false        // ← nouveau
    var servings: Int? = nil            // Nouveauté — nombre de personnes (optionnel pour compatibilité)
    var imageUrl: String? = nil
    
    // Propriété de compatibilité — retourne la première catégorie
    var category: RecipeCategory {
        categories.first ?? .other
    }

    init(
        id: UUID = UUID(),
        title: String,
        categories: [RecipeCategory],
        ingredients: [String],
        steps: [String],
        calories: Int,
        protein: Double,
        carbs: Double,
        fats: Double,
        createdAt: Date = Date(),
        servings: Int? = nil
    ) {
        self.id          = id
        self.title       = title
        self.categories  = categories
        self.ingredients = ingredients
        self.steps       = steps
        self.calories    = calories
        self.protein     = protein
        self.carbs       = carbs
        self.fats        = fats
        self.createdAt   = createdAt
        self.servings    = servings
    }
}
