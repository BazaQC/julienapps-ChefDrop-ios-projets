// ============================================
// RecipeCategory+Localization.swift
// ChefDrop — Models/
// ============================================
import Foundation

extension RecipeCategory {

    func localizedName(_ localeManager: LocaleManager) -> String {
        switch self {
        // Protéines
        case .chicken:      return localeManager.t("Poulet", "Chicken")
        case .beef:         return localeManager.t("Bœuf", "Beef")
        case .pork:         return localeManager.t("Porc", "Pork")
        case .fish:         return localeManager.t("Poisson", "Fish")
        case .seafood:      return localeManager.t("Fruits de mer", "Seafood")
        case .turkey:       return localeManager.t("Dinde", "Turkey")
        case .eggs:         return localeManager.t("Œufs", "Eggs")
        case .lamb:         return localeManager.t("Agneau", "Lamb")
        case .duck:         return localeManager.t("Canard", "Duck")
        case .otherProtein: return localeManager.t("Autre protéine", "Other Protein")

        // Plats
        case .pasta:        return localeManager.t("Pâtes", "Pasta")
        case .rice:         return localeManager.t("Riz", "Rice")
        case .soup:         return localeManager.t("Soupe", "Soup")
        case .salad:        return localeManager.t("Salade", "Salad")
        case .sandwich:     return localeManager.t("Sandwich", "Sandwich")
        case .pizza:        return localeManager.t("Pizza", "Pizza")
        case .burger:       return localeManager.t("Burger", "Burger")
        case .tacos:        return localeManager.t("Tacos", "Tacos")
        case .breakfast:    return localeManager.t("Déjeuner", "Breakfast")
        case .dessert:      return localeManager.t("Dessert", "Dessert")
        case .smoothie:     return localeManager.t("Smoothie", "Smoothie")
        case .wok:          return localeManager.t("Wok", "Wok")
        case .snack:        return localeManager.t("Collation", "Snack")
        case .bbq:          return localeManager.t("BBQ", "BBQ")
        case .fromage:      return localeManager.t("Fromage", "Cheese")
        case .otherMeal:    return localeManager.t("Autre plat", "Other Meal")

        // Styles
        case .vegetarian:   return localeManager.t("Végétarien", "Vegetarian")
        case .vegan:        return localeManager.t("Végétalien", "Vegan")
        case .glutenFree:   return localeManager.t("Sans gluten", "Gluten-Free")
        case .legumineuse:  return localeManager.t("Légumineuse", "Legume")
        case .toffu:        return localeManager.t("Tofu", "Tofu")
        case .sansLactose:  return localeManager.t("Sans lactose", "Lactose-Free")
        case .sansNoix:     return localeManager.t("Sans noix", "Nut-Free")
        case .keto:         return localeManager.t("Keto", "Keto")
        case .balanced:     return localeManager.t("Équilibré", "Balanced")
        case .otherStyle:   return localeManager.t("Autre style", "Other Style")

        // Fitness
        case .highProtein:  return localeManager.t("Haute protéine", "High Protein")
        case .lowCalorie:   return localeManager.t("Faible calorie", "Low Calorie")
        case .lowFat:       return localeManager.t("Faible gras", "Low Fat")
        case .lowCarb:      return localeManager.t("Faible glucide", "Low Carb")
        case .bulk:         return localeManager.t("Prise de masse", "Bulk")

        // Autre
        case .other:        return localeManager.t("Autre", "Other")
        }
    }

    var iconName: String {
        switch self {
        // Protéines
        case .chicken:      return "icon_poulet"
        case .beef:         return "icon_boeuf"
        case .pork:         return "icon_porc"
        case .fish:         return "icon_poisson"
        case .seafood:      return "icon_fruit_de_mer"
        case .turkey:       return "icon_dinde"
        case .eggs:         return "icon_oeuf"
        case .lamb:         return "icon_agneau"
        case .duck:         return "icon_canard"
        case .otherProtein: return "icon_autre_rouge"

        // Plats
        case .pasta:        return "icon_pate"
        case .rice:         return "icon_riz"
        case .soup:         return "icon_soupe"
        case .salad:        return "icon_salade"
        case .sandwich:     return "icon_sandwich"
        case .pizza:        return "icon_pizza"
        case .burger:       return "icon_burger"
        case .tacos:        return "icon_tacos"
        case .breakfast:    return "icon_dejeuner"
        case .dessert:      return "icon_dessert"
        case .smoothie:     return "icon_smoothie"
        case .wok:          return "icon_wok"
        case .snack:        return "icon_collation"
        case .bbq:          return "icon_bbq"
        case .fromage:      return "icon_fromage"
        case .otherMeal:    return "icon_autre_jaune"

        // Styles
        case .vegetarian:   return "icon_vegetarien"
        case .vegan:        return "icon_vegetalien"
        case .glutenFree:   return "icon_sans_gluten"
        case .legumineuse:  return "icon_legumineuse"
        case .toffu:        return "icon_tofu"
        case .sansLactose:  return "icon_sans_lactose"
        case .sansNoix:     return "icon_sans_noix"
        case .keto:         return "icon_keto"
        case .balanced:     return "icon_equilibre"
        case .otherStyle:   return "icon_autre_vert"

        // Fitness
        case .highProtein:  return "icon_proteine"
        case .lowCalorie:   return "icon_low_calorie"
        case .lowFat:       return "icon_low_fat"
        case .lowCarb:      return "icon_low_carb"
        case .bulk:         return "icon_prise_de_masse"
        case .other:        return "icon_autre_bleu"
        }
    }
}
