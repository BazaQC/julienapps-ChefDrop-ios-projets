//
//  SupaBaseConfig.swift
//  ChefDrop
//
//  Created by Julien Carmel on 2026-03-26.
//

struct SupabaseConfig {
    static let anonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNva3BtY3d3emFocHh1dHRibGtlIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQ0OTE3NTUsImV4cCI6MjA5MDA2Nzc1NX0.PsKI-Ncn1GFdVDXzAJrjo00bwK3_a2EihaaNGgCk1vw"
    static let functionURL = "https://cokpmcwwzahpxuttblke.supabase.co/functions/v1/super-api"
}

