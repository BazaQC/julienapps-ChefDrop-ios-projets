//
//  SupabaseImageService.swift
//  ChefDrop
//
//  Created by Julien Carmel on 2026-03-26.
//

import Foundation

class SupabaseImageService {
    static let shared = SupabaseImageService()
    private let baseURL = "https://cokpmcwwzahpxuttblke.supabase.co/functions/v1/fetchRecipeImage"
    
    func fetchImage(for title: String) async throws -> String {
        guard let url = URL(string: baseURL) else {
            throw URLError(.badURL)
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue(SupabaseConfig.anonKey, forHTTPHeaderField: "apikey")
        request.addValue("Bearer \(SupabaseConfig.anonKey)", forHTTPHeaderField: "Authorization")
        
        let body = ["title": title]
        request.httpBody = try JSONEncoder().encode(body)
        
        let (data, response) = try await URLSession.shared.data(for: request)
        
        // Debug temporaire
        if let httpResponse = response as? HTTPURLResponse {
            print("� Status Supabase:", httpResponse.statusCode)
        }
        if let raw = String(data: data, encoding: .utf8) {
            print("� Réponse brute:", raw)
        }
        
        let result = try JSONDecoder().decode(ImageResponse.self, from: data)
        return result.imageUrl
    }
}

struct ImageResponse: Codable {
    let imageUrl: String
}
