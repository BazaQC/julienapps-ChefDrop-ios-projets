// ============================================
// LocaleManager.swift
// ChefDrop — Services/
// ============================================
import SwiftUI

@Observable
class LocaleManager {
    
    static let shared = LocaleManager()
    
    var isEnglish: Bool {
        didSet {
            UserDefaults.standard.set(isEnglish, forKey: "isEnglish")
        }
    }
    
    private init() {
        self.isEnglish = UserDefaults.standard.bool(forKey: "isEnglish")
    }
    
    func t(_ french: String, _ english: String) -> String {
        return isEnglish ? english : french
    }
}

