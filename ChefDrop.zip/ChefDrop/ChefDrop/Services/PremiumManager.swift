// ============================================
// PremiumManager.swift
// ChefDrop
//
// Service qui gère les achats in-app StoreKit 2.
// Produits CONSOMMABLES (crédits empilables).
// Vérifie les transactions et notifie le ViewModel.
// ============================================
 
import StoreKit
import SwiftUI
 
// MARK: - Product IDs
// Identifiants des produits dans App Store Connect
// Type : Consommable (pas abonnement)
extension PremiumManager {
    enum ProductID {
        static let starter = "com.tonprenom.ChefDrop.credits.starter"  // 2,99$ — 30 crédits
        static let chef    = "com.tonprenom.ChefDrop.credits.chef"     // 5,99$ — 120 crédits
        static let pro     = "com.tonprenom.ChefDrop.credits.pro"      // 9,99$ — 300 crédits
 
        // Mapping ID -> CreditPack
        static func pack(for productID: String) -> CreditPack? {
            switch productID {
            case starter: return .starter
            case chef:    return .chef
            case pro:     return .pro
            default:      return nil
            }
        }
    }
}
 
// MARK: - PremiumManager
@Observable
class PremiumManager {
 
    // MARK: - Propriétés Publiques
 
    // Produits disponibles chargés depuis l'App Store
    var availableProducts: [Product] = []
 
    // État du chargement des produits
    var isLoading: Bool = false
 
    // Message d'erreur si achat échoue
    var errorMessage: String? = nil
 
    // Dernier pack acheté avec succès — lu par PremiumViewModel
    var lastPurchasedPack: CreditPack? = nil
 
    // MARK: - Propriétés Privées
 
    // Tâche d'écoute des transactions en arrière-plan
    private var transactionListener: Task<Void, Error>? = nil
 
    // MARK: - Init
    init() {
        transactionListener = listenForTransactions()
    }
 
    deinit {
        transactionListener?.cancel()
    }
 
    // MARK: - Charger les Produits
 
    /// Charge les produits disponibles depuis l'App Store
    @MainActor
    func loadProducts() async {
        isLoading = true
        do {
            availableProducts = try await Product.products(for: [
                ProductID.starter,
                ProductID.chef,
                ProductID.pro
            ])
            // Trie par prix croissant
            availableProducts.sort { $0.price < $1.price }
        } catch {
            errorMessage = "Impossible de charger les produits."
            print("❌ Erreur chargement produits: \(error)")
        }
        isLoading = false
    }
 
    // MARK: - Acheter un Produit
 
    /// Lance l'achat d'un produit StoreKit consommable
    @MainActor
    func purchase(_ product: Product) async {
        isLoading = true
        errorMessage = nil
        lastPurchasedPack = nil
 
        do {
            let result = try await product.purchase()
 
            switch result {
            case .success(let verification):
                let transaction = try checkVerified(verification)
                // Identifie quel pack a été acheté
                if let pack = ProductID.pack(for: transaction.productID) {
                    lastPurchasedPack = pack
                }
                await transaction.finish()
 
            case .userCancelled:
                print("ℹ️ Achat annulé par l'utilisateur")
 
            case .pending:
                print("⏳ Achat en attente d'approbation")
 
            @unknown default:
                break
            }
        } catch {
            errorMessage = "Erreur lors de l'achat. Réessaie."
            print("❌ Erreur achat: \(error)")
        }
 
        isLoading = false
    }
 
    // MARK: - Restaurer les Achats
 
    /// Note : les consommables ne sont pas restaurables via StoreKit
    /// Cette fonction existe pour la conformité UI mais ne fait rien de fonctionnel
    @MainActor
    func restorePurchases() async {
        // Les achats consommables ne se restaurent pas — comportement Apple standard
        print("ℹ️ Restauration appelée — les crédits consommables ne sont pas restaurables")
    }
 
    // MARK: - Fonctions Privées
 
    /// Écoute les transactions en temps réel
    private func listenForTransactions() -> Task<Void, Error> {
        return Task.detached {
            for await result in StoreKit.Transaction.updates {
                do {
                    let transaction = try self.checkVerified(result)
                    await transaction.finish()
                    print("✅ Transaction en arrière-plan traitée: \(transaction.productID)")
                } catch {
                    print("❌ Transaction invalide: \(error)")
                }
            }
        }
    }
 
    /// Vérifie qu'une transaction StoreKit est légitime
    private func checkVerified<T>(_ result: VerificationResult<T>) throws -> T {
        switch result {
        case .unverified:
            throw StoreError.failedVerification
        case .verified(let safe):
            return safe
        }
    }
}
 
// MARK: - StoreError
enum StoreError: Error {
    case failedVerification
}
