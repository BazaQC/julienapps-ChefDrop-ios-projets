//
//  Photo.swift
//  ChefDrop
//
//  Created by Julien Carmel on 2026-03-26.
//

import Foundation

struct PhotoService {
    private let accessKey = "dFUkjJ6dIsh4Qtfr4FsldlHNYtpiPTx12xHvsEl_CA8"

    func fetchImageURL(for query: String) async throws -> URL? {
        // Construire l’URL de l’API Unsplash
        var components = URLComponents(string: "https://api.unsplash.com/photos/random")!
        components.queryItems = [
            URLQueryItem(name: "query", value: query),
            URLQueryItem(name: "orientation", value: "landscape"),
            URLQueryItem(name: "w", value: "1600"),
        ]

        guard let url = components.url else {
            return nil
        }

        // Préparer la requête HTTP
        var request = URLRequest(url: url)
        request.setValue("Client-ID \(accessKey)", forHTTPHeaderField: "Authorization")

        // Appel réseau
        let (data, response) = try await URLSession.shared.data(for: request)

        guard let httpResponse = response as? HTTPURLResponse,
              (200...299).contains(httpResponse.statusCode) else {
            return nil
        }

        // Décoder la réponse JSON
        let photo = try JSONDecoder().decode(UnsplashPhoto.self, from: data)

        // Retourner l’URL de l’image
        return URL(string: photo.urls.full)
    }
}

// MARK: - Models

struct UnsplashPhoto: Decodable {
    let urls: UnsplashPhotoURLs
}

struct UnsplashPhotoURLs: Decodable {
    let regular: String
    let full: String
}
