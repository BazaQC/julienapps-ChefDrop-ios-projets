import Foundation

struct RecipeParser {
    
    // ============================================
    // � INTERRUPTEUR PRINCIPAL
    // true  = Utilise ton nouveau système Supabase
    // false = Utilise le mode test sans internet
    // ============================================
    private let USE_AI = true
    
    // ============================================
    // MARK: - Point d'entrée principal
    // ============================================
    func parseRecipe(from text: String, localeManager: LocaleManager) async -> Recipe? {
        if USE_AI {
            return await parseWithSupabase(from: text)
        } else {
            return await parseWithMock(from: text, localeManager: localeManager)
        }
    }
    
    // ============================================
    // MARK: - MODE PRODUCTION : Appel via Supabase
    // ============================================
    private func parseWithSupabase(from text: String) async -> Recipe? {
        
        let prompt = text
        
        guard let url = URL(string: SupabaseConfig.functionURL) else {
            print("❌ URL Supabase invalide")
            return nil
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        // On utilise la Anon Key pour s'identifier auprès de Supabase
        request.setValue("Bearer \(SupabaseConfig.anonKey)", forHTTPHeaderField: "Authorization")
        
        let body: [String: Any] = ["prompt": prompt]
        
        guard let httpBody = try? JSONSerialization.data(withJSONObject: body) else { return nil }
        request.httpBody = httpBody
        
        do {
            let (data, response) = try await URLSession.shared.data(for: request)
            
            if let httpResponse = response as? HTTPURLResponse, !(200...299).contains(httpResponse.statusCode) {
                print("❌ Erreur Supabase (Code \(httpResponse.statusCode))")
                return nil
            }
            
            if let rawText = String(data: data, encoding: .utf8) {
                return buildRecipe(from: rawText)
            }
            return nil
            
        } catch {
            print("❌ Erreur réseau : \(error.localizedDescription)")
            return nil
        }
    }
    
    // ============================================
    // MARK: - Construire Recipe depuis JSON
    // ============================================
    private func buildRecipe(from jsonString: String) -> Recipe? {
        
        let cleaned = jsonString
            .replacingOccurrences(of: "```json", with: "")
            .replacingOccurrences(of: "```", with: "")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        
        guard
            let data = cleaned.data(using: .utf8),
            let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any]
        else {
            print("❌ JSON invalide: \(jsonString)")
            return nil
        }
        
        let title       = json["title"] as? String ?? "Recette importée"
        let ingredients = json["ingredients"] as? [String] ?? []
        let steps       = json["steps"] as? [String] ?? []
        let calories    = json["calories"] as? Int ?? 400
        let protein     = json["protein"] as? Double ?? 30.0
        let carbs       = json["carbs"] as? Double ?? 25.0
        let fats        = json["fats"] as? Double ?? 12.0

        // Parsing tolerant pour "servings" : peut être Int ou String (ex: "4 personnes")
        var servingsValue: Int? = nil
        if let sInt = json["servings"] as? Int {
            servingsValue = sInt
        } else if let sStr = json["servings"] as? String {
            if let digits = sStr.range(of: "\\d+", options: .regularExpression) {
                servingsValue = Int(String(sStr[digits]))
            }
        }

        let categoriesRaw   = json["categories"] as? [String] ?? ["Other"]
        let categories      = categoriesRaw.compactMap { RecipeCategory(rawValue: $0) }
        var autoCategories  = categories.isEmpty ? [RecipeCategory.other] : categories

        // ✅ Auto-détection fitness selon les macros (par portion)
        let perServing        = max(1, servingsValue ?? 1)
        let calPerServing     = calories / perServing
        let fatPerServing     = fats / Double(perServing)
        let carbPerServing    = carbs / Double(perServing)
        let proteinPerServing = protein / Double(perServing)

        if calPerServing <= 400  && !autoCategories.contains(.lowCalorie)  { autoCategories.append(.lowCalorie) }
        if fatPerServing <= 10   && !autoCategories.contains(.lowFat)      { autoCategories.append(.lowFat) }
        if carbPerServing <= 30  && !autoCategories.contains(.lowCarb)     { autoCategories.append(.lowCarb) }
        if proteinPerServing >= 30 && !autoCategories.contains(.highProtein) { autoCategories.append(.highProtein) }
        if calPerServing >= 500 && proteinPerServing >= 30 && !autoCategories.contains(.bulk) { autoCategories.append(.bulk) }

        return Recipe(
            title: title,
            categories: autoCategories,
            ingredients: ingredients,
            steps: steps,
            calories: calories,
            protein: protein,
            carbs: carbs,
            fats: fats,
            servings: servingsValue
        )
    }
    // ============================================
    // MARK: - MODE TEST : Mock gratuit
    // ============================================
    private func parseWithMock(from text: String, localeManager: LocaleManager) async -> Recipe? {
        let lowered    = text.lowercased()
        let categories = detectCategories(from: lowered)
        let title      = extractTitle(from: text, category: categories.first ?? .other, localeManager: localeManager)
        
        return Recipe(
            title: title,
            categories: categories,
            ingredients: mockIngredients(for: categories.first ?? .other),
            steps: mockSteps(for: categories.first ?? .other),
            calories: Int.random(in: 350...700),
            protein: Double.random(in: 25...55),
            carbs: Double.random(in: 20...60),
            fats: Double.random(in: 8...25),
            servings: Int.random(in: 1...6)
        )
    }
    
    // ============================================
    // MARK: - Détection de catégories
    // ============================================
    func detectCategories(from text: String) -> [RecipeCategory] {
        var found: [RecipeCategory] = []
        
        // 🔴 Protéines
        if text.contains("poulet") || text.contains("chicken") { found.append(.chicken) }
        if text.contains("boeuf") || text.contains("beef") || text.contains("steak") { found.append(.beef) }
        if text.contains("porc") || text.contains("pork") { found.append(.pork) }
        if text.contains("saumon") || text.contains("poisson") || text.contains("fish") { found.append(.fish) }
        if text.contains("crevette") || text.contains("seafood") { found.append(.seafood) }
        if text.contains("dinde") || text.contains("turkey") { found.append(.turkey) }
        if text.contains("oeuf") || text.contains("eggs") { found.append(.eggs) }
        if text.contains("agneau") || text.contains("lamb") { found.append(.lamb) }
        if text.contains("canard") || text.contains("duck") || text.contains("magret") { found.append(.duck) }      // ← nouveau
        if text.contains("tofu") || text.contains("toffu") { found.append(.toffu) }
        if text.contains("lentille") || text.contains("légumineuse") { found.append(.legumineuse) }
        if text.contains("fromage") || text.contains("cheese") { found.append(.fromage) }
        
        // 🟡 Plats
        if text.contains("pâtes") || text.contains("pasta") { found.append(.pasta) }
        if text.contains(" riz") || text.contains("de riz") || text.contains(" rice") { found.append(.rice) }
        if text.contains("soupe") || text.contains("soup") { found.append(.soup) }
        if text.contains("salade") || text.contains("salad") { found.append(.salad) }
        if text.contains("sandwich") || text.contains("wrap") { found.append(.sandwich) }
        if text.contains("pizza") { found.append(.pizza) }
        if text.contains("burger") || text.contains("hamburger") { found.append(.burger) }
        if text.contains("tacos") || text.contains("taco") { found.append(.tacos) }
        if text.contains("déjeuner") || text.contains("breakfast") { found.append(.breakfast) }
        if text.contains("dessert") || text.contains("gâteau") { found.append(.dessert) }
        if text.contains("smoothie") || text.contains("shake") { found.append(.smoothie) }
        if text.contains("wok") || text.contains("sauté") { found.append(.wok) }
        if text.contains("collation") || text.contains("snack") || text.contains("en-cas") || text.contains("goûter") { found.append(.snack) }  // ← nouveau
        if text.contains("bbq") || text.contains("barbecue") || text.contains("grillé") || text.contains("grilled") { found.append(.bbq) }      // ← nouveau
        
        // 🟢 Styles
        if text.contains("végétalien") || text.contains("vegan") { found.append(.vegan) }
        if text.contains("végétarien") || text.contains("vegetarian") { found.append(.vegetarian) }
        if text.contains("sans gluten") || text.contains("gluten-free") { found.append(.glutenFree) }
        if text.contains("sans lactose") || text.contains("lactose-free") { found.append(.sansLactose) }
        if text.contains("sans noix") || text.contains("nut-free") { found.append(.sansNoix) }
        if text.contains("keto") || text.contains("cétogène") { found.append(.keto) }
        if text.contains("équilibré") || text.contains("balanced") { found.append(.balanced) }
        
        // � Fitness
        if text.contains("haute protéine") || text.contains("high protein") { found.append(.highProtein) }
        if text.contains("faible calorie") || text.contains("low calorie")  { found.append(.lowCalorie) }
        if text.contains("faible gras")    || text.contains("low fat")      { found.append(.lowFat) }
        if text.contains("faible glucide") || text.contains("low carb")     { found.append(.lowCarb) }
        if text.contains("prise de masse") || text.contains("bulk")         { found.append(.bulk) }
        
        return found.isEmpty ? [.otherProtein] : found
    }
    
    func extractTitle(from text: String, category: RecipeCategory, localeManager: LocaleManager) -> String {
        let lines = text
            .components(separatedBy: .newlines)
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
        
        for line in lines.prefix(5) {
            if line.count > 3 && line.count < 60 && !line.contains(":") {
                return line
            }
        }
        return localeManager.t("Recette de \(category.localizedName(localeManager))", "\(category.rawValue) Recipe")
    }
    
    // ============================================
    // MARK: - Mock ingrédients
    // ============================================
    func mockIngredients(for category: RecipeCategory) -> [String] {
        switch category {
        case .chicken:
            return ["2 poitrines de poulet","2 citrons","3 gousses d'ail","2 c. à soupe d'huile d'olive","Sel et poivre","Thym frais"]
        case .beef:
            return ["500g de boeuf haché","1 oignon","2 gousses d'ail","1 c. à soupe d'huile","Sel et poivre","Sauce Worcestershire"]
        case .pork:
            return ["500g de filet de porc","2 c. à soupe de miel","2 c. à soupe de sauce soya","2 gousses d'ail","Sel et poivre","Romarin"]
        case .fish:
            return ["2 filets de saumon","1 citron","2 c. à soupe d'huile d'olive","Aneth frais","Sel et poivre","1 gousse d'ail"]
        case .seafood:
            return ["400g de crevettes","3 gousses d'ail","2 c. à soupe de beurre","Persil frais","1 citron","Sel et poivre"]
        case .turkey:
            return ["500g de dinde hachée","1 oignon","2 gousses d'ail","1 c. à soupe d'huile","Sel et poivre","Sauge"]
        case .eggs:
            return ["4 oeufs","2 c. à soupe de lait","1 c. à soupe de beurre","Sel et poivre","Ciboulette","Fromage râpé"]
        case .lamb:
            return ["500g d'agneau haché","1 oignon","3 gousses d'ail","2 c. à soupe d'huile d'olive","Cumin et coriandre","Sel et poivre"]
        case .duck:                                                                                                   // ← nouveau
            return ["2 magrets de canard","2 c. à soupe de miel","1 orange","2 gousses d'ail","Sel et poivre","Thym frais"]
        case .pasta:
            return ["350g de spaghetti","200g de lardons","3 jaunes d'oeuf","100g de parmesan râpé","Poivre noir","1 c. à soupe d'huile"]
        case .rice:
            return ["300g de riz basmati","600ml de bouillon","1 oignon","2 gousses d'ail","1 c. à soupe d'huile","Sel et poivre"]
        case .soup:
            return ["1L de bouillon de poulet","2 carottes","2 branches de céleri","1 oignon","2 gousses d'ail","Sel et poivre"]
        case .salad:
            return ["200g de laitue romaine","100g de tomates cerises","50g de parmesan","Croûtons","3 c. à soupe d'huile d'olive","Jus de citron"]
        case .sandwich:
            return ["2 tranches de pain","100g de poulet grillé","1 feuille de laitue","2 tranches de tomate","Mayonnaise","Moutarde"]
        case .pizza:
            return ["1 pâte à pizza","100ml de sauce tomate","150g de mozzarella","Basilic frais","2 c. à soupe d'huile d'olive","Sel et poivre"]
        case .burger:
            return ["500g de boeuf haché","4 pains briochés","4 tranches de cheddar","1 oignon rouge","2 tomates","Laitue, mayo, ketchup"]
        case .tacos:
            return ["400g de boeuf haché","8 tortillas","1 oignon","2 gousses d'ail","Épices à tacos","Salsa, crème sure, fromage"]
        case .breakfast:
            return ["3 oeufs","2 tranches de pain","1 avocat","Sel et poivre","Jus de citron","Flocons de chili"]
        case .dessert:
            return ["200g de farine","150g de sucre","100g de beurre","2 oeufs","1 c. à thé de vanille","1 c. à thé de poudre à pâte"]
        case .smoothie:
            return ["1 banane","200ml de lait d'amande","100g de fraises","1 c. à soupe de miel","1 c. à soupe de graines de chia","Glaçons"]
        case .wok:
            return ["300g de poulet en lanières","2 poivrons","1 courgette","3 c. à soupe de sauce soya","2 gousses d'ail","1 c. à soupe d'huile de sésame"]
        case .snack:                                                                                                  // ← nouveau
            return ["200g de fromage en cubes","100g de charcuterie","Crackers","Raisins frais","Noix mélangées","Miel"]
        case .bbq:                                                                                                    // ← nouveau
            return ["600g de côtes levées","3 c. à soupe de sauce BBQ","2 c. à soupe de cassonade","1 c. à thé de paprika fumé","Sel et poivre","1 c. à thé d'ail en poudre"]
        case .fromage:
            return ["200g de fromage raclette","4 pommes de terre","100g de charcuterie","Cornichons","Poivre noir","Salade verte"]
        case .vegetarian:
            return ["2 poivrons","1 courgette","1 aubergine","200g de tomates cerises","3 c. à soupe d'huile d'olive","Herbes de Provence"]
        case .vegan:
            return ["400g de pois chiches","2 c. à soupe d'huile d'olive","2 gousses d'ail","1 c. à thé de cumin","Paprika fumé","Sel et poivre"]
        case .glutenFree:
            return ["300g de riz","200g de légumes variés","2 c. à soupe d'huile d'olive","2 gousses d'ail","Herbes fraîches","Sel et poivre"]
        case .legumineuse:
            return ["400g de lentilles vertes","1 oignon","2 gousses d'ail","2 carottes","2 c. à soupe d'huile d'olive","Cumin et coriandre"]
        case .toffu:
            return ["400g de tofu ferme","3 c. à soupe de sauce soya","2 c. à soupe d'huile de sésame","2 gousses d'ail","1 c. à soupe de gingembre","Graines de sésame"]
        case .sansLactose:
            return ["300g de poulet","2 c. à soupe d'huile de coco","2 gousses d'ail","200g de légumes variés","Lait de coco","Sel et poivre"]
        case .sansNoix:
            return ["300g de pâtes","200g de tomates cerises","2 c. à soupe d'huile d'olive","Basilic frais","2 gousses d'ail","Sel et poivre"]
        case .keto:
            return ["300g de saumon","200g d'épinards","2 c. à soupe de beurre","2 gousses d'ail","100ml de crème 35%","Sel et poivre"]
        case .balanced:
            return ["200g de poulet","150g de quinoa","200g de légumes variés","2 c. à soupe d'huile d'olive","Jus de citron","Herbes fraîches"]
        case .otherStyle:
            return ["Ingrédient 1","Ingrédient 2","Ingrédient 3","Épices au goût"]
        case .otherProtein:
            return ["Protéine principale","Assaisonnement au goût","Huile d'olive","Sel et poivre","Herbes fraîches","Légumes au choix"]
        case .otherMeal:
            return ["Ingrédient principal","Garniture au choix","Sauce au goût","Épices","Sel et poivre","Herbes fraîches"]
        case .other:
            return ["Ingrédient 1","Ingrédient 2","Ingrédient 3","Épices au goût"]
        case .highProtein:
            return ["300g de poulet","200g de riz brun","4 œufs","200g de cottage cheese","100g de quinoa","Épices au goût"]
        case .lowCalorie:
            return ["300g de légumes variés","200g de poulet","2 c. à soupe d'huile d'olive","Herbes fraîches","Sel et poivre","Jus de citron"]
        case .lowFat:
            return ["300g de blanc de poulet","200g de légumes vapeur","150g de riz","Épices sans sel","Jus de citron","Herbes fraîches"]
        case .lowCarb:
            return ["300g de saumon","200g d'épinards","2 c. à soupe d'huile d'olive","2 gousses d'ail","100ml de crème","Sel et poivre"]
        case .bulk:
            return ["400g de bœuf haché","300g de riz","4 œufs","2 c. à soupe d'huile","100g de fromage","Pain de blé entier"]
        }
    }
    
    // ============================================
    // MARK: - Mock étapes
    // ============================================
    func mockSteps(for category: RecipeCategory) -> [String] {
        switch category {
        case .chicken:
            return ["Préchauffer le four à 200°C.","Mariner le poulet avec l'ail, le citron, l'huile, sel et poivre pendant 15 min.","Placer dans un plat allant au four.","Cuire 25-30 minutes jusqu'à dorure.","Laisser reposer 5 minutes avant de servir."]
        case .beef:
            return ["Chauffer l'huile dans une poêle à feu moyen-vif.","Faire revenir l'oignon et l'ail 3 minutes.","Ajouter le boeuf haché et cuire 8 minutes.","Assaisonner et ajouter la sauce Worcestershire.","Servir chaud."]
        case .pork:
            return ["Mélanger le miel, sauce soya et ail pour la marinade.","Mariner le filet de porc 30 minutes.","Chauffer une poêle à feu vif avec un peu d'huile.","Cuire 4-5 minutes de chaque côté.","Laisser reposer 5 minutes avant de trancher."]
        case .fish:
            return ["Préchauffer le four à 190°C.","Assaisonner les filets avec sel, poivre et aneth.","Arroser d'huile d'olive et de jus de citron.","Cuire au four 12-15 minutes.","Servir avec des légumes grillés."]
        case .seafood:
            return ["Faire fondre le beurre dans une poêle à feu moyen.","Ajouter l'ail et cuire 1 minute.","Ajouter les crevettes et cuire 2-3 minutes de chaque côté.","Assaisonner et ajouter le jus de citron.","Garnir de persil frais et servir."]
        case .turkey:
            return ["Chauffer l'huile dans une poêle à feu moyen.","Faire revenir l'oignon et l'ail 3 minutes.","Ajouter la dinde hachée et cuire 8 minutes.","Assaisonner avec sel, poivre et sauge.","Servir chaud."]
        case .eggs:
            return ["Battre les oeufs avec le lait, sel et poivre.","Faire fondre le beurre dans une poêle à feu doux.","Verser les oeufs et remuer doucement.","Retirer du feu quand encore légèrement coulants.","Garnir de ciboulette et fromage."]
        case .lamb:
            return ["Chauffer l'huile dans une poêle à feu vif.","Faire revenir l'oignon et l'ail 3 minutes.","Ajouter l'agneau et cuire 8 minutes.","Assaisonner avec cumin et coriandre.","Servir chaud avec du pain pita."]
        case .duck:                                                                                                   // ← nouveau
            return ["Quadriller la peau des magrets au couteau sans atteindre la chair.","Assaisonner avec sel et poivre.","Déposer côté peau dans une poêle froide et monter à feu moyen.","Cuire 8 minutes côté peau puis 4 minutes côté chair.","Laisser reposer 5 minutes, napper de miel et jus d'orange avant de servir."]
        case .pasta:
            return ["Cuire les spaghetti al dente.","Faire revenir les lardons jusqu'à croustillant.","Mélanger les jaunes d'oeuf et le parmesan.","Égoutter les pâtes en gardant l'eau de cuisson.","Mélanger tout hors du feu et servir."]
        case .rice:
            return ["Rincer le riz jusqu'à eau claire.","Faire revenir l'oignon et l'ail dans l'huile.","Ajouter le riz et faire revenir 2 minutes.","Ajouter le bouillon et porter à ébullition.","Couvrir et cuire à feu doux 18 minutes."]
        case .soup:
            return ["Faire revenir l'oignon et l'ail dans l'huile.","Ajouter les carottes et le céleri coupés.","Verser le bouillon et porter à ébullition.","Réduire le feu et laisser mijoter 20 minutes.","Assaisonner et servir chaud."]
        case .salad:
            return ["Laver et couper la laitue romaine.","Couper les tomates cerises en deux.","Mélanger l'huile et le citron pour la vinaigrette.","Assembler la salade et ajouter le parmesan.","Garnir de croûtons et servir immédiatement."]
        case .sandwich:
            return ["Griller les tranches de pain.","Mélanger mayo et moutarde et étaler sur le pain.","Déposer la laitue et les tranches de tomate.","Ajouter le poulet grillé tranché.","Refermer et servir immédiatement."]
        case .pizza:
            return ["Préchauffer le four à 220°C.","Étaler la pâte sur une plaque farinée.","Étaler la sauce tomate uniformément.","Ajouter la mozzarella et les garnitures.","Cuire 12-15 minutes jusqu'à dorure."]
        case .burger:
            return ["Former 4 galettes de boeuf, assaisonner.","Cuire à la poêle 3-4 minutes de chaque côté.","Ajouter le cheddar la dernière minute.","Griller les pains briochés.","Assembler avec laitue, tomate, oignon et sauces."]
        case .tacos:
            return ["Faire revenir l'oignon et l'ail dans l'huile.","Ajouter le boeuf haché et les épices à tacos.","Cuire 8 minutes en remuant.","Réchauffer les tortillas à la poêle.","Garnir de viande, salsa, crème sure et fromage."]
        case .breakfast:
            return ["Griller les tranches de pain.","Écraser l'avocat avec sel, poivre et citron.","Cuire les oeufs à votre goût.","Étaler l'avocat sur le pain grillé.","Garnir de flocons de chili et servir."]
        case .dessert:
            return ["Préchauffer le four à 180°C.","Mélanger le beurre et le sucre jusqu'à crémeux.","Ajouter les oeufs et la vanille.","Incorporer la farine et la poudre à pâte.","Cuire 25-30 minutes et laisser refroidir."]
        case .smoothie:
            return ["Peler et trancher la banane.","Mettre tous les ingrédients dans le blender.","Mixer 60 secondes jusqu'à consistance lisse.","Ajouter des glaçons si désiré et remixer.","Servir immédiatement dans un grand verre."]
        case .wok:
            return ["Chauffer l'huile de sésame dans le wok à feu très vif.","Faire sauter l'ail 30 secondes.","Ajouter le poulet et cuire 5 minutes.","Ajouter les légumes et la sauce soya.","Mélanger rapidement et servir immédiatement."]
        case .snack:                                                                                                  // ← nouveau
            return ["Couper le fromage en cubes.","Disposer la charcuterie sur une planche.","Ajouter les crackers et les raisins.","Garnir de noix et d'un filet de miel.","Servir à température ambiante."]
        case .bbq:                                                                                                    // ← nouveau
            return ["Mélanger cassonade, paprika, ail en poudre, sel et poivre pour le rub.","Enduire les côtes du mélange et laisser reposer 30 minutes.","Préchauffer le BBQ à feu moyen-doux.","Cuire les côtes 1h30 en retournant toutes les 20 minutes.","Badigeonner de sauce BBQ les 15 dernières minutes et servir."]
        case .fromage:
            return ["Cuire les pommes de terre 20 minutes à l'eau bouillante.","Préchauffer l'appareil à raclette.","Disposer la charcuterie et les cornichons.","Faire fondre le fromage sur les pommes de terre.","Servir immédiatement et déguster."]
        case .vegetarian:
            return ["Préchauffer le four à 200°C.","Couper tous les légumes en morceaux.","Mélanger avec l'huile et les herbes.","Étaler sur une plaque et assaisonner.","Cuire 25-30 minutes jusqu'à caramélisation."]
        case .vegan:
            return ["Égoutter et rincer les pois chiches.","Mélanger avec l'huile, l'ail et les épices.","Étaler sur une plaque de cuisson.","Cuire au four à 200°C pendant 30 minutes.","Servir avec une sauce tahini et du persil."]
        case .glutenFree:
            return ["Cuire le riz selon les instructions.","Faire revenir l'ail dans l'huile.","Ajouter les légumes et cuire 5 minutes.","Assaisonner avec les herbes fraîches.","Servir le riz avec les légumes et déguster."]
        case .legumineuse:
            return ["Rincer les lentilles à l'eau froide.","Faire revenir l'oignon, l'ail et les carottes 5 minutes.","Ajouter les lentilles et couvrir d'eau.","Cuire à feu doux 25 minutes.","Assaisonner avec cumin, coriandre, sel et poivre."]
        case .toffu:
            return ["Égoutter et presser le tofu pour enlever l'eau.","Couper en cubes et mariner dans la sauce soya 15 minutes.","Chauffer l'huile de sésame dans une poêle à feu vif.","Faire dorer le tofu 3-4 minutes de chaque côté.","Garnir de graines de sésame et servir."]
        case .sansLactose:
            return ["Chauffer l'huile de coco dans une poêle.","Faire revenir l'ail 1 minute.","Ajouter le poulet et cuire 6 minutes de chaque côté.","Incorporer le lait de coco et les légumes.","Laisser mijoter 10 minutes et servir."]
        case .sansNoix:
            return ["Cuire les pâtes al dente selon les instructions.","Faire revenir l'ail dans l'huile d'olive.","Ajouter les tomates cerises et cuire 5 minutes.","Mélanger avec les pâtes égouttées.","Garnir de basilic frais et servir."]
        case .keto:
            return ["Préchauffer le four à 190°C.","Assaisonner le saumon avec sel et poivre.","Faire fondre le beurre dans une poêle allant au four.","Saisir le saumon 2 minutes puis ajouter la crème et l'ail.","Enfourner 10 minutes et servir sur les épinards sautés."]
        case .balanced:
            return ["Cuire le quinoa dans le double de son volume d'eau 15 minutes.","Assaisonner le poulet et cuire à la poêle 6 minutes de chaque côté.","Faire sauter les légumes à l'huile d'olive 5 minutes.","Trancher le poulet et disposer sur le quinoa.","Arroser de jus de citron et garnir d'herbes fraîches."]
        case .otherStyle:
            return ["Préparer tous les ingrédients.","Suivre les étapes de la recette.","Assaisonner selon vos préférences.","Servir chaud et déguster."]
        case .otherProtein:
            return ["Préparer la protéine principale.","Assaisonner selon vos préférences.","Cuire à feu moyen jusqu'à cuisson complète.","Ajouter les légumes et herbes.","Servir chaud."]
        case .otherMeal:
            return ["Préparer tous les ingrédients.","Cuire selon le type de plat.","Assaisonner au goût.","Dresser dans une assiette.","Servir et déguster."]
        case .other:
            return ["Préparer tous les ingrédients.","Suivre les étapes de la recette.","Assaisonner selon vos préférences.","Servir chaud et déguster."]
        case .highProtein:
            return ["Cuire le riz brun 20 minutes dans 400ml d'eau salée.","Griller le poulet à feu moyen 6 minutes de chaque côté.","Cuire les œufs durs 10 minutes.","Assembler dans un bol avec le quinoa.","Assaisonner et servir."]
        case .lowCalorie:
            return ["Couper tous les légumes en morceaux égaux.","Chauffer l'huile à feu moyen et faire revenir l'ail 1 minute.","Ajouter les légumes et cuire 5 minutes en remuant.","Ajouter le poulet et cuire 6 minutes de chaque côté.","Assaisonner avec herbes et jus de citron, servir."]
        case .lowFat:
            return ["Cuire le riz à la vapeur 18 minutes.","Assaisonner le poulet avec épices et jus de citron.","Cuire le poulet au four à 190°C pendant 25 minutes.","Cuire les légumes à la vapeur 8 minutes.","Assembler dans une assiette et servir."]
        case .lowCarb:
            return ["Préchauffer le four à 190°C.","Assaisonner le saumon avec sel, poivre et ail.","Faire fondre l'huile dans une poêle et saisir le saumon 2 minutes.","Ajouter la crème et les épinards, laisser mijoter 5 minutes.","Servir chaud."]
        case .bulk:
            return ["Cuire le riz dans 600ml d'eau salée pendant 18 minutes.","Faire revenir le bœuf haché à feu vif 8 minutes.","Ajouter le fromage et les épices, mélanger.","Cuire les œufs au plat dans une poêle beurrée.","Assembler avec le riz et servir immédiatement."]
        }
    }
}
