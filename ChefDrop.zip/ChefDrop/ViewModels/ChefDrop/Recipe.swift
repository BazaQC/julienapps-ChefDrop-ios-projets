//
//  Recipe.swift
//  ChefDrop
//
//  Created by Julien Carmel on 2026-03-18.
//


enum RecipeCategory {
    case chicken
    case beef
    case pasta
    case breakfast
    case other

    var imageName: String {
        switch self {
        case .chicken:   return "img_chicken"
        case .beef:      return "img_beef"
        case .pasta:     return "img_pasta"
        case .breakfast: return "img_breakfast"
        case .other:     return "img_other"
        }
    }
}
