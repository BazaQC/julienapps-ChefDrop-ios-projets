//
//  ContentView.swift
//  ChefDrop
//
//  Created by Julien Carmel on 2026-03-18.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("Hello, ChefDrop!")
            .padding()
    }
}

#Preview {
    ContentView()
}
