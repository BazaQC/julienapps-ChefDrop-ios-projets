// ChefDrop.swift
// Minimal app entry

import SwiftUI

@main
struct ChefDrop: App {
    @AppStorage("isLightMode") private var isLightMode: Bool = false

    var body: some Scene {
        WindowGroup {
            ContentView()
                .preferredColorScheme(isLightMode ? .light : .dark)
        }
    }
}
