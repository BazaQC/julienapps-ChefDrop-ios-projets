// ============================================
// RecipeViewModel.swift
// ChefDrop
//
// Cerveau principal de l'application.
// Gère toutes les opérations sur les recettes :
// - Charger, sauvegarder, supprimer
// - Filtrer par catégorie
// - Vérifier les limites du plan freemium
// ============================================

import SwiftUI
import SwiftData

// MARK: - RecipeViewModel
// @Observable remplace @ObservableObject en iOS 17+
// Les Views se mettent à jour automatiquement quand les données changent
@Observable
class RecipeViewModel {
    
    // MARK: - Propriétés
    
    // Liste de toutes les recettes sauvegardées
    var recipes: [Recipe] = []
    
    // Catégorie sélectionnée dans le menu latéral (nil = toutes les recettes)
    var selectedCategory: RecipeCategory? = nil
    
    // Contrôle l'affichage du PaywallView
    var showPaywall: Bool = false
    
    // Contrôle l'affichage du menu latéral
    var showSideMenu: Bool = false
    
    // MARK: - Recettes Filtrées
    // Retourne les recettes selon la catégorie sélectionnée
    var filteredRecipes: [Recipe] {
        // Si aucune catégorie sélectionnée, retourne toutes les recettes
        guard let category = selectedCategory else {
            return recipes
        }
        // Sinon filtre par catégorie
        return recipes.filter { $0.category == category }
    }
    
    // MARK: - Sauvegarder une Recette
    // Ajoute une nouvelle recette dans SwiftData
    func saveRecipe(_ recipe: Recipe, context: ModelContext) {
        
        // Vérifie si l'utilisateur a atteint sa limite freemium
        // PremiumManager sera créé dans la Conversation E
        if recipes.count >= 10 {
            // Affiche le paywall si limite atteinte
            showPaywall = true
            return
        }
        
        // Insère la recette dans la base de données locale
        context.insert(recipe)
        
        // Recharge la liste pour mettre à jour l'UI
        loadRecipes(context: context)
    }
    
    // MARK: - Charger les Recettes
    // Récupère toutes les recettes depuis SwiftData
    func loadRecipes(context: ModelContext) {
        do {
            // Crée une requête pour récupérer toutes les recettes
            // Triées par date de création (plus récente en premier)
            let descriptor = FetchDescriptor<Recipe>(
                sortBy: [SortDescriptor(\.createdAt, order: .reverse)]
            )
            recipes = try context.fetch(descriptor)
        } catch {
            // Si erreur, log dans la console Xcode
            print("❌ Erreur chargement recettes: \(error)")
        }
    }
    
    // MARK: - Supprimer une Recette
    // Supprime une recette de SwiftData
    func deleteRecipe(_ recipe: Recipe, context: ModelContext) {
        context.delete(recipe)
        loadRecipes(context: context)
    }
    
    // MARK: - Sélectionner une Catégorie
    // Appelé depuis le SideMenu quand l'utilisateur choisit une catégorie
    func selectCategory(_ category: RecipeCategory?) {
        selectedCategory = category
        // Ferme le menu latéral après sélection
        showSideMenu = false
    }
}
