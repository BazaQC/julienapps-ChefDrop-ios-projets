//
//  ChefDropApp.swift
//  ChefDrop
//
//  Created by Julien Carmel on 2026-03-18.
//

import SwiftUI

// Original demo app entry removed. Use `ChefDrop.swift` as the app entry point.
